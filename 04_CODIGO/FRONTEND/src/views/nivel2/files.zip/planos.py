# 04_CODIGO/BACKEND/app/api/v1/planos.py
import logging
from collections import defaultdict
from typing import List, Optional
from uuid import UUID
from datetime import date, datetime

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from pydantic import BaseModel, validator, Field

from app.db.database import get_db
from app.db.models import Plano, Proyecto, PedidoDetalle, OTDetalle
from app.services.asignacion import ESTADO_OT_ANULADA, cantidades_asignadas

router = APIRouter()
audit = logging.getLogger("sgi.audit")

SECUENCIA_ESTADOS = ["ABIERTA", "PLANIFICADA", "EN_DISENO", "LIBERADA"]
# Campos documentales críticos: una vez LIBERADA, cambiarlos exige motivo (PDF puntos 8 y 9)
CAMPOS_CRITICOS = ("codigo_plano", "revision", "archivo_url", "material_requerido")


class PiezaPlanoItem(BaseModel):
    codigo_plano: str = Field(..., description="Código del plano técnico")
    revision: Optional[str] = "REV-01"
    detalle_pieza: str = Field(..., description="Nombre o detalle de la pieza")
    cantidad: Optional[int] = 1
    material_requerido: Optional[str] = Field(None, description="Materia Prima / Especificación BOM")
    archivo_url: Optional[str] = Field(None, description="URL del archivo PDF del plano")


class AsignacionLinea(BaseModel):
    """Qué línea del pedido ejecuta esta OT y cuántas unidades (PDF puntos 3 y 4)."""
    detalle_id: UUID
    cantidad: int = Field(..., ge=1)


class AsignacionOTResponse(BaseModel):
    ot_detalle_id: UUID
    detalle_id: UUID
    cantidad_asignada: int

    class Config:
        from_attributes = True


class PlanoCreate(BaseModel):
    id_proyecto: Optional[UUID] = None
    numero_pedido: Optional[str] = Field(None, description="N° Pedido Agrupador Comercial")
    codigo_op: str = Field(..., description="Código OP por área")
    codigo_plano: Optional[str] = "PLN-MEC-001"
    revision: Optional[str] = "REV-01"
    dibujante_asignado: Optional[str] = "Carlos Ruiz"
    unidad_planta: Optional[str] = "Mecanizados"
    estado_diseno: Optional[str] = "PLANIFICADA"
    causa_espera: Optional[str] = None
    material_requerido: Optional[str] = None
    insumos_opcionales: Optional[str] = None
    tiempo_estimado_valor: Optional[int] = 4
    tiempo_estimado_unidad: Optional[str] = "HORAS"
    dias_estimados_diseno: Optional[int] = 2
    dias_espera_planificacion: Optional[int] = 0
    fecha_inicio_programada: Optional[date] = None
    fecha_entrega_cliente: Optional[date] = None
    fecha_entrega_produccion: Optional[date] = None
    archivo_url: Optional[str] = None
    piezas: Optional[List[PiezaPlanoItem]] = Field(default_factory=list)
    asignaciones: Optional[List[AsignacionLinea]] = Field(default_factory=list)

    @validator('fecha_entrega_cliente', 'fecha_entrega_produccion', 'fecha_inicio_programada', pre=True)
    def parse_fechas_vacias(cls, v):
        if v == "" or v is None:
            return None
        return v

    @validator('id_proyecto', pre=True)
    def parse_id_vacio(cls, v):
        return None if v == "" else v

    class Config:
        extra = "ignore"


class PlanoUpdate(BaseModel):
    codigo_op: Optional[str] = None
    codigo_plano: Optional[str] = None
    revision: Optional[str] = None
    dibujante_asignado: Optional[str] = None
    unidad_planta: Optional[str] = None
    estado_diseno: Optional[str] = None
    causa_espera: Optional[str] = None
    material_requerido: Optional[str] = None
    tiempo_estimado_valor: Optional[int] = None
    tiempo_estimado_unidad: Optional[str] = None
    fecha_inicio_programada: Optional[date] = None
    fecha_entrega_cliente: Optional[date] = None
    fecha_entrega_produccion: Optional[date] = None
    archivo_url: Optional[str] = None
    motivo_cambio: Optional[str] = Field(None, description="Obligatorio al cambiar datos críticos de una OT LIBERADA")

    @validator('causa_espera', pre=True)
    def parse_causa_vacia(cls, v):
        if v == "" or v == "Sin demoras / Restricción resuelta":
            return None
        return v

    @validator('fecha_entrega_cliente', 'fecha_entrega_produccion', 'fecha_inicio_programada', pre=True)
    def parse_fechas_vacias(cls, v):
        if v == "" or v is None:
            return None
        return v


class AnularOT(BaseModel):
    motivo: str = Field(..., min_length=5)


class PlanoResponse(BaseModel):
    id_plano: UUID
    id_proyecto: Optional[UUID] = None
    codigo_op: Optional[str] = "4007256"
    numero_pedido: Optional[str] = None
    codigo_plano: str
    revision: str
    dibujante_asignado: Optional[str] = None
    unidad_planta: Optional[str] = None
    estado_diseno: Optional[str] = "PLANIFICADA"
    causa_espera: Optional[str] = None
    material_requerido: Optional[str] = None
    tiempo_estimado_valor: Optional[int] = 4
    tiempo_estimado_unidad: Optional[str] = "HORAS"
    fecha_inicio_programada: Optional[date] = None
    fecha_entrega_produccion: Optional[date] = None
    archivo_url: Optional[str] = None
    creado_en: datetime
    asignaciones: List[AsignacionOTResponse] = Field(default_factory=list)  # líneas que ejecuta la OT

    class Config:
        from_attributes = True


def _respuestas(db: Session, planos: List[Plano]) -> List[PlanoResponse]:
    ids = [p.id_plano for p in planos]
    por_ot = defaultdict(list)
    if ids:
        for a in db.query(OTDetalle).filter(OTDetalle.ot_id.in_(ids)).all():
            por_ot[a.ot_id].append(AsignacionOTResponse.model_validate(a))
    resultado = []
    for p in planos:
        r = PlanoResponse.model_validate(p)
        r.asignaciones = por_ot.get(p.id_plano, [])
        resultado.append(r)
    return resultado


@router.get("/", response_model=List[PlanoResponse])
def listar_planos(db: Session = Depends(get_db)):
    return _respuestas(db, db.query(Plano).order_by(Plano.creado_en.desc()).all())


@router.post("/", response_model=PlanoResponse, status_code=status.HTTP_201_CREATED)
def crear_plano(plano_in: PlanoCreate, db: Session = Depends(get_db)):
    datos_plano = plano_in.dict(exclude={"piezas", "asignaciones"}, exclude_none=True)

    # --- 1) Resolver el pedido y validar las líneas/cantidades que ejecutará la OT ---
    proyecto = None
    if plano_in.id_proyecto:
        proyecto = db.query(Proyecto).filter(Proyecto.id_proyecto == plano_in.id_proyecto).first()
    elif plano_in.numero_pedido:
        proyecto = db.query(Proyecto).filter(Proyecto.numero_pedido == plano_in.numero_pedido).first()

    asignaciones = {}
    for a in plano_in.asignaciones or []:          # fusiona duplicados de una misma línea
        asignaciones[a.detalle_id] = asignaciones.get(a.detalle_id, 0) + a.cantidad

    if asignaciones:
        if not proyecto:
            raise HTTPException(status_code=400, detail="Para asignar líneas debe indicar un pedido válido.")

        detalles = (
            db.query(PedidoDetalle)
            .filter(PedidoDetalle.detalle_id.in_(list(asignaciones)),
                    PedidoDetalle.pedido_id == proyecto.id_proyecto)
            .with_for_update()
            .all()
        )
        if len(detalles) != len(asignaciones):
            raise HTTPException(status_code=400, detail="Alguna línea no pertenece al pedido indicado.")

        ya_asignado = cantidades_asignadas(db, list(asignaciones))
        for det in detalles:
            pendiente = (det.cantidad_solicitada or 0) - ya_asignado.get(det.detalle_id, 0)
            if asignaciones[det.detalle_id] > pendiente:
                raise HTTPException(
                    status_code=409,
                    detail=f"Línea '{det.descripcion}': se piden {asignaciones[det.detalle_id]} UND "
                           f"pero solo quedan {max(pendiente, 0)} pendientes.",
                )

    if proyecto:
        datos_plano["id_proyecto"] = proyecto.id_proyecto
        datos_plano["numero_pedido"] = proyecto.numero_pedido

    columnas_validas = {c.name for c in Plano.__table__.columns}
    datos_filtrados = {k: v for k, v in datos_plano.items() if k in columnas_validas}

    # Compatibilidad con el flujo anterior basado en "piezas"
    if plano_in.piezas:
        codigos = [p.codigo_plano for p in plano_in.piezas if p.codigo_plano]
        if codigos:
            datos_filtrados["codigo_plano"] = codigos[0]
        mats = [p.material_requerido for p in plano_in.piezas if p.material_requerido]
        if mats:
            datos_filtrados["material_requerido"] = mats[0]

    # --- 2) Crear OT + OT_DETALLE en una sola transacción ---
    nuevo_plano = Plano(**datos_filtrados)
    db.add(nuevo_plano)
    db.flush()

    for detalle_id, cantidad in asignaciones.items():
        db.add(OTDetalle(ot_id=nuevo_plano.id_plano, detalle_id=detalle_id, cantidad_asignada=cantidad))

    db.commit()
    db.refresh(nuevo_plano)
    audit.info("OT_CREADA ot=%s pedido=%s asignaciones=%s",
               nuevo_plano.codigo_op, nuevo_plano.numero_pedido, {str(k): v for k, v in asignaciones.items()})
    return _respuestas(db, [nuevo_plano])[0]


@router.patch("/{id_plano}", response_model=PlanoResponse)
def actualizar_plano(id_plano: UUID, plano_up: PlanoUpdate, db: Session = Depends(get_db)):
    plano = db.query(Plano).filter(Plano.id_plano == id_plano).first()
    if not plano:
        raise HTTPException(status_code=404, detail="Orden de diseño no encontrada.")

    estado_actual = plano.estado_diseno or "PLANIFICADA"
    if estado_actual == ESTADO_OT_ANULADA:
        raise HTTPException(status_code=409, detail="La OT está ANULADA y no admite cambios.")

    datos_update = plano_up.dict(exclude_unset=True)
    motivo = (datos_update.pop("motivo_cambio", None) or "").strip()

    # --- Flujo de estados validado en servidor (antes solo estaba en el frontend) ---
    nuevo_estado = datos_update.get("estado_diseno")
    if nuevo_estado and nuevo_estado != estado_actual:
        if nuevo_estado not in SECUENCIA_ESTADOS:
            raise HTTPException(status_code=422, detail="Para anular use POST /planos/{id}/anular.")
        idx_a, idx_n = SECUENCIA_ESTADOS.index(estado_actual), SECUENCIA_ESTADOS.index(nuevo_estado)
        if idx_n != idx_a + 1:
            raise HTTPException(status_code=409,
                                detail=f"Transición no permitida: {estado_actual} → {nuevo_estado}.")
        if nuevo_estado == "LIBERADA":
            archivo = datos_update.get("archivo_url", plano.archivo_url)
            if not (archivo or "").strip():
                raise HTTPException(status_code=409,
                                    detail="No se puede LIBERAR la OT sin el archivo del plano técnico.")

    # --- Control de cambios sobre datos críticos de una OT LIBERADA ---
    if estado_actual == "LIBERADA":
        cambios = [c for c in CAMPOS_CRITICOS
                   if c in datos_update and datos_update[c] != getattr(plano, c, None)]
        if cambios and len(motivo) < 5:
            raise HTTPException(
                status_code=409,
                detail=f"OT LIBERADA: para modificar {', '.join(cambios)} indique 'motivo_cambio' (mín. 5 caracteres).",
            )

    # Si la orden avanza a EN_DISENO o LIBERADA, se remueve automáticamente la causa de espera
    if datos_update.get("estado_diseno") in ["EN_DISENO", "LIBERADA"]:
        datos_update["causa_espera"] = None

    for campo, valor in datos_update.items():
        anterior = getattr(plano, campo, None)
        if anterior != valor:
            audit.info("OT_CAMBIO ot=%s campo=%s anterior=%r nuevo=%r motivo=%r",
                       plano.codigo_op, campo, anterior, valor, motivo)
        setattr(plano, campo, valor)

    db.commit()
    db.refresh(plano)
    return _respuestas(db, [plano])[0]


@router.post("/{id_plano}/anular", response_model=PlanoResponse)
def anular_plano(id_plano: UUID, cuerpo: AnularOT, db: Session = Depends(get_db)):
    """No se elimina: se anula con motivo, se conserva el historial y se libera la cantidad
    asignada para que el pedido vuelva a tenerla como pendiente (PDF punto 9)."""
    plano = db.query(Plano).filter(Plano.id_plano == id_plano).first()
    if not plano:
        raise HTTPException(status_code=404, detail="Orden de diseño no encontrada.")
    if plano.estado_diseno == ESTADO_OT_ANULADA:
        raise HTTPException(status_code=409, detail="La OT ya está anulada.")

    audit.info("OT_ANULADA ot=%s estado_anterior=%s motivo=%r",
               plano.codigo_op, plano.estado_diseno, cuerpo.motivo)
    plano.estado_diseno = ESTADO_OT_ANULADA
    plano.causa_espera = None
    db.commit()
    db.refresh(plano)
    return _respuestas(db, [plano])[0]
