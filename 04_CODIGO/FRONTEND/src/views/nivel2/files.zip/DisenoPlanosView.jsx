import React, { useState, useEffect } from 'react';
import API from '../../services/api';

export default function DisenoPlanosView() {
  const [planos, setPlanos] = useState([]);
  const [pedidosEntrantes, setPedidosEntrantes] = useState([]);
  const [loading, setLoading] = useState(false);
  const [mensaje, setMensaje] = useState({ tipo: '', texto: '' });
  const [busqueda, setBusqueda] = useState('');
  const [busquedaBandeja, setBusquedaBandeja] = useState('');
  const [filtroEstado, setFiltroEstado] = useState('TODOS');
  const [filtroBandeja, setFiltroBandeja] = useState('PENDIENTES');

  // Estado para colapsar/desplegar la Bandeja de Recepción
  const [bandejaAbierta, setBandejaAbierta] = useState(true);

  // Modales
  const [modalPedidoAbierto, setModalPedidoAbierto] = useState(false);
  const [pedidoSeleccionado, setPedidoSeleccionado] = useState(null);

  const [modalOpAbierto, setModalOpAbierto] = useState(false);
  const [opSeleccionada, setOpSeleccionada] = useState(null);

  const [modalHistoricoClienteAbierto, setModalHistoricoClienteAbierto] = useState(false);
  const [clienteHistoricoSeleccionado, setClienteHistoricoSeleccionado] = useState(null);

  const [modalNuevoPlanoAbierto, setModalNuevoPlanoAbierto] = useState(false);
  const [nuevoPlano, setNuevoPlano] = useState({
    id_proyecto: '',
    numero_pedido: '',
    id_linea: '',
    codigo_op: '4007256',
    codigo_plano: '',
    revision: 'REV-01',
    dibujante_asignado: 'Ing. Carlos Ruiz',
    unidad_planta: 'Mecanizados',
    estado_diseno: 'PLANIFICADA',
    causa_espera: 'En espera de la muestra de la pieza',
    tiempo_estimado_valor: 4,
    tiempo_estimado_unidad: 'HORAS',
    fecha_inicio_programada: '',
    fecha_entrega_cliente: '',
    fecha_entrega_produccion: '',
    material_requerido: 'Acero ASTM A105',
    archivo_url: '',
    piezas: []
  });

  const SECUENCIA_ESTADOS = ['ABIERTA', 'PLANIFICADA', 'EN_DISENO', 'LIBERADA'];

  const OPCIONES_CAUSA_ESPERA = [
    'Falta visita al cliente para toma de medidas',
    'El cliente no ha enviado los planos',
    'En espera de la muestra de la pieza'
  ];

  useEffect(() => {
    cargarPlanosYPedidos();
  }, []);

  const cargarPlanosYPedidos = async () => {
    try {
      setLoading(true);
      const resPlanos = await API.get('/planos/');
      setPlanos(Array.isArray(resPlanos.data) ? resPlanos.data : []);

      const resPedidos = await API.get('/proyectos/');
      setPedidosEntrantes(Array.isArray(resPedidos.data) ? resPedidos.data : []);
    } catch (error) {
      try {
        const fetchRes = await fetch('http://127.0.0.1:8000/api/v1/planos/');
        const data = await fetchRes.json();
        setPlanos(Array.isArray(data) ? data : []);

        const fetchPed = await fetch('http://127.0.0.1:8000/api/v1/proyectos/');
        const dataPed = await fetchPed.json();
        setPedidosEntrantes(Array.isArray(dataPed) ? dataPed : []);
      } catch (err) {
        setMensaje({ tipo: 'error', texto: 'No se pudo conectar con el servidor Backend.' });
      }
    } finally {
      setLoading(false);
    }
  };

  const calcularDiasEnEstado = (fechaCreacion) => {
    if (!fechaCreacion) return 0;
    const inicio = new Date(fechaCreacion);
    const hoy = new Date();
    const dias = Math.floor((hoy - inicio) / (1000 * 60 * 60 * 24));
    return dias >= 0 ? dias : 0;
  };

  const handleCambioUnidadPlanta = (unidad) => {
    let codigoOpSugerido = '4007256';
    if (unidad === 'Metalistería') codigoOpSugerido = '1002395';
    if (unidad === 'Servicios') codigoOpSugerido = '3002534';

    setNuevoPlano(prev => ({
      ...prev,
      unidad_planta: unidad,
      codigo_op: codigoOpSugerido
    }));
  };

  // Cambio directo de la Causa de Espera desde la tabla principal
  const handleCambiarCausaEsperaTabla = async (plano, nuevaCausa) => {
    setMensaje({ tipo: '', texto: '' });
    try {
      setLoading(true);
      const idPlanoTarget = plano.id_plano;
      if (!idPlanoTarget) {
        setMensaje({ tipo: 'error', texto: 'No se encontró el ID único de la orden seleccionada.' });
        return;
      }

      const causaFinal = (nuevaCausa === '' || nuevaCausa === 'RESUELTA') ? null : nuevaCausa;

      await API.patch(`/planos/${idPlanoTarget}`, { 
        causa_espera: causaFinal
      });

      setMensaje({ 
        tipo: 'exito', 
        texto: causaFinal 
          ? `✅ Causa de espera actualizada a "${causaFinal}" para OT-${plano.codigo_op}.` 
          : `✅ Causa de espera resuelta y levantada correctamente para OT-${plano.codigo_op}.` 
      });
      cargarPlanosYPedidos();
    } catch (error) {
      console.error("Error al actualizar la causa de espera:", error);
      setMensaje({ tipo: 'error', texto: 'No se pudo actualizar la causa de espera.' });
    } finally {
      setLoading(false);
    }
  };

  const handleCambiarEtapaOrden = async (plano, nuevoEstado) => {
    setMensaje({ tipo: '', texto: '' });
    const estadoActual = plano.estado_diseno || 'PLANIFICADA';
    const idxActual = SECUENCIA_ESTADOS.indexOf(estadoActual);
    const idxNuevo = SECUENCIA_ESTADOS.indexOf(nuevoEstado);

    if (idxNuevo !== idxActual + 1) {
      if (idxNuevo < idxActual) {
        alert(`⚠️ Regla ISO 9001: No se permite retroceder de ${estadoActual} a ${nuevoEstado}.`);
      } else {
        alert(`⚠️ Flujo Incompleto: Debe pasar secuencialmente por las etapas de Ingeniería (${SECUENCIA_ESTADOS[idxActual + 1]}). No puede saltar a ${nuevoEstado}.`);
      }
      return;
    }

    if (nuevoEstado === 'LIBERADA') {
      const tienePlanoCargado = plano.archivo_url && plano.archivo_url.trim() !== '';
      if (!tienePlanoCargado) {
        alert("❌ Bloqueo de Calidad (ISO 9001): No se puede LIBERAR la orden a Producción sin haber asignado o cargado el archivo PDF del plano técnico.");
        return;
      }
    }

    let causaSeleccionada = plano.causa_espera || null;
    
    // Al avanzar a EN_DISENO o LIBERADA, se remueve automáticamente la causa de espera
    if (nuevoEstado === 'EN_DISENO' || nuevoEstado === 'LIBERADA') {
      causaSeleccionada = null;
    } else if (nuevoEstado === 'PLANIFICADA' && !causaSeleccionada) {
      const msj = "Seleccione la Causa de Espera:\n1. Falta visita al cliente para toma de medidas\n2. El cliente no ha enviado los planos\n3. En espera de la muestra de la pieza\n\nEscriba el número (1, 2 o 3) o detalle otra razón:";
      const resp = prompt(msj);
      if (!resp) {
        alert("Es obligatorio seleccionar una causa de espera para la etapa PLANIFICADA.");
        return;
      }
      if (resp === '1') causaSeleccionada = OPCIONES_CAUSA_ESPERA[0];
      else if (resp === '2') causaSeleccionada = OPCIONES_CAUSA_ESPERA[1];
      else if (resp === '3') causaSeleccionada = OPCIONES_CAUSA_ESPERA[2];
      else causaSeleccionada = resp;
    }

    try {
      setLoading(true);
      const idPlanoTarget = plano.id_plano;
      if (!idPlanoTarget) {
        setMensaje({ tipo: 'error', texto: 'No se encontró el ID único de la orden seleccionada.' });
        return;
      }

      await API.patch(`/planos/${idPlanoTarget}`, { 
        estado_diseno: nuevoEstado,
        causa_espera: causaSeleccionada
      });

      setMensaje({ tipo: 'exito', texto: `✅ Estado de la Orden OT-${plano.codigo_op} actualizado a ${nuevoEstado}.${nuevoEstado === 'EN_DISENO' ? ' (Causa de espera resuelta y levantada)' : ''}` });
      cargarPlanosYPedidos();
    } catch (error) {
      console.error("Error al actualizar estado:", error);
      setMensaje({ tipo: 'error', texto: 'No se pudo cambiar el estado de la orden.' });
    } finally {
      setLoading(false);
    }
  };

  // Muestra el expediente con la jerarquía CLIENTE ➔ PEDIDO ➔ LÍNEAS ➔ OTs
  const handleAbrirExpedientePedido = (e, numeroPedido) => {
    e.stopPropagation();
    setMensaje({ tipo: '', texto: '' });
    const pedidoEncontrado = pedidosEntrantes.find(p => p.numero_pedido === numeroPedido) || {};
    const ordenesAsociadas = planos.filter(pl => pl.numero_pedido === numeroPedido);

    // Mapear líneas / piezas del pedido asociadas a sus OTs
    const lineasDesglosadas = (pedidoEncontrado.detalles || []).map((it, idx) => {
      const idsOtActivas = new Set(
        (it.ot_detalles || []).filter(ot => ot.estado_ot !== 'ANULADA').map(ot => ot.ot_id)
      );
      return {
        numero_linea: idx + 1,
        detalle_pieza: it.descripcion || 'Pieza / Servicio',
        cantidad: it.cantidad_solicitada || 1,
        cantidad_asignada: it.cantidad_asignada || 0,
        cantidad_pendiente: it.cantidad_pendiente ?? 0,
        material_requerido: it.material_requerido || '—',
        ordenes: ordenesAsociadas.filter(o => idsOtActivas.has(o.id_plano))
      };
    });

    setPedidoSeleccionado({
      numero_pedido: numeroPedido,
      cliente_nombre: pedidoEncontrado.cliente_nombre || 'Cliente General',
      contacto_nombre: pedidoEncontrado.contacto_nombre || 'Contacto Comercial',
      ubicacion_cliente: pedidoEncontrado.ubicacion_cliente || 'Planta Principal',
      fecha_compromiso: pedidoEncontrado.fecha_compromiso || 'Sin Fecha',
      requisitos_cliente: pedidoEncontrado.requisitos_cliente || 'Estándar ISO 9001:2026',
      detalle_producto: pedidoEncontrado.detalle_producto || 'Lote de Piezas',
      cantidad: pedidoEncontrado.cantidad || 1,
      lineas: lineasDesglosadas.length > 0 ? lineasDesglosadas : [{
        numero_linea: 1,
        detalle_pieza: pedidoEncontrado.detalle_producto || 'Pieza Mecanizada',
        cantidad: pedidoEncontrado.cantidad || 1,
        material_requerido: 'Acero ASTM A105',
        ordenes: ordenesAsociadas
      }],
      ordenes: ordenesAsociadas
    });
    setModalPedidoAbierto(true);
  };

  const handleAbrirExpedienteOp = (e, pl) => {
    e.stopPropagation();
    setMensaje({ tipo: '', texto: '' });
    setOpSeleccionada(pl);
    setModalOpAbierto(true);
  };

  const handleAbrirHistoricoClienteUbicacion = (clienteNombre, ubicacionCliente) => {
    setMensaje({ tipo: '', texto: '' });
    const pedidosCliente = pedidosEntrantes.filter(p => 
      p.cliente_nombre === clienteNombre && (p.ubicacion_cliente === ubicacionCliente || !ubicacionCliente)
    );
    const ordenesCliente = planos.filter(p => 
      pedidosCliente.some(ped => ped.numero_pedido === p.numero_pedido)
    );

    setClienteHistoricoSeleccionado({
      cliente_nombre: clienteNombre,
      ubicacion_cliente: ubicacionCliente || 'Planta Principal',
      pedidos: pedidosCliente,
      ordenes: ordenesCliente
    });
    setModalHistoricoClienteAbierto(true);
  };

  const handleAsignarOpDesdePedido = (pedido) => {
    setMensaje({ tipo: '', texto: '' });
    
    const prefijo = pedido.numero_pedido ? pedido.numero_pedido.replace('PED-', '') : '001';
    const lineasPendientes = (pedido.detalles || []).filter(d => (d.cantidad_pendiente || 0) > 0);

    if (lineasPendientes.length === 0) {
      setMensaje({ tipo: 'error', texto: 'Este pedido no tiene líneas con cantidad pendiente por asignar.' });
      return;
    }

    // Una fila por línea con pendiente; por defecto se propone asignar todo lo pendiente
    const piezasIniciales = lineasPendientes.map((d, index) => ({
      id: Date.now() + index,
      detalle_id: d.detalle_id,
      codigo_plano: `PLN-${prefijo}-${String.fromCharCode(65 + index)}`,
      revision: 'REV-01',
      detalle_pieza: d.descripcion || 'Pieza / Servicio Requerido',
      cantidad: d.cantidad_pendiente,
      cantidad_pendiente: d.cantidad_pendiente,
      cantidad_solicitada: d.cantidad_solicitada,
      material_requerido: d.material_requerido || 'Acero ASTM A105',
      archivo_url: ''
    }));

    const codigoOpSugerido = pedido.codigo_proyecto && pedido.codigo_proyecto !== 'S/P' 
      ? pedido.codigo_proyecto 
      : '4007256';

    setNuevoPlano({
      id_proyecto: pedido.id_proyecto || '',
      numero_pedido: pedido.numero_pedido || '',
      codigo_op: codigoOpSugerido,
      codigo_plano: piezasIniciales[0].codigo_plano,
      revision: 'REV-01',
      dibujante_asignado: 'Ing. Carlos Ruiz',
      unidad_planta: 'Mecanizados',
      estado_diseno: 'PLANIFICADA',
      causa_espera: 'En espera de la muestra de la pieza',
      tiempo_estimado_valor: 4,
      tiempo_estimado_unidad: 'HORAS',
      fecha_inicio_programada: '',
      fecha_entrega_cliente: pedido.fecha_compromiso || '',
      fecha_entrega_produccion: pedido.fecha_compromiso || '',
      material_requerido: piezasIniciales[0].material_requerido,
      archivo_url: '',
      piezas: piezasIniciales
    });
    setModalNuevoPlanoAbierto(true);
  };

  const handleCambioPieza = (id, campo, valor) => {
    setNuevoPlano(prev => ({
      ...prev,
      piezas: prev.piezas.map(p => {
        if (p.id !== id) return p;
        if (campo === 'cantidad') {
          const max = p.cantidad_pendiente ?? Infinity;
          return { ...p, cantidad: Math.max(0, Math.min(valor, max)) };
        }
        return { ...p, [campo]: valor };
      })
    }));
  };

  const handleCrearOrdenDiseno = async (e) => {
    e.preventDefault();
    setMensaje({ tipo: '', texto: '' });

    try {
      setLoading(true);
      // Solo las líneas con cantidad > 0 forman parte de esta OT (una línea puede repartirse en varias OTs)
      const piezasOt = nuevoPlano.piezas.filter(p => (p.cantidad || 0) > 0);
      if (piezasOt.length === 0) {
        setMensaje({ tipo: 'error', texto: 'Asigne al menos una línea con cantidad mayor a 0 a esta OT.' });
        return;
      }
      const payload = {
        ...nuevoPlano,
        estado_diseno: 'PLANIFICADA',
        piezas: piezasOt.map(({ id, detalle_id, cantidad_pendiente, cantidad_solicitada, ...resto }) => resto),
        asignaciones: piezasOt
          .filter(p => p.detalle_id)
          .map(p => ({ detalle_id: p.detalle_id, cantidad: p.cantidad }))
      };
      await API.post('/planos/', payload);
      setMensaje({ tipo: 'exito', texto: `✅ Orden de Trabajo OT-${nuevoPlano.codigo_op} asignada correctamente en Estado PLANIFICADA.` });
      setModalNuevoPlanoAbierto(false);
      
      setFiltroEstado('TODOS');
      await cargarPlanosYPedidos();
    } catch (error) {
      const detalle = error?.response?.data?.detail;
      setMensaje({
        tipo: 'error',
        texto: typeof detalle === 'string' ? `⚠️ ${detalle}` : 'Error al registrar la orden de diseño.'
      });
    } finally {
      setLoading(false);
    }
  };

  // Bandeja operativa: NO se ocultan pedidos con OT; el estado lo calcula el backend
  const FILTROS_BANDEJA = [
    { id: 'TODOS', label: 'Todos' },
    { id: 'PENDIENTES', label: 'Pendientes' },
    { id: 'EN_ESTRUCTURACION', label: 'En estructuración' },
    { id: 'PARCIALES', label: 'Parciales' },
    { id: 'ASIGNADOS', label: 'Asignados' },
    { id: 'BLOQUEADOS', label: 'Bloqueados' },
    { id: 'CERRADOS', label: 'Cerrados' },
  ];

  const cumpleFiltroBandeja = (ped, filtro) => {
    switch (filtro) {
      case 'PENDIENTES': return (ped.total_pendiente || 0) > 0;
      case 'EN_ESTRUCTURACION': return ped.estado_pedido === 'EN_ESTRUCTURACION';
      case 'PARCIALES': return ped.estado_pedido === 'PARCIALMENTE_ASIGNADO';
      case 'ASIGNADOS': return ped.estado_pedido === 'ASIGNADO';
      case 'BLOQUEADOS': return !!ped.bloqueado;
      case 'CERRADOS': return ['ENTREGADO', 'CERRADO', 'CANCELADO'].includes(ped.estado_pedido);
      default: return true;
    }
  };

  const ESTILO_ESTADO_PEDIDO = {
    RECIBIDO: 'bg-slate-100 text-slate-700 border-slate-300',
    EN_ESTRUCTURACION: 'bg-blue-100 text-blue-800 border-blue-300',
    PARCIALMENTE_ASIGNADO: 'bg-amber-100 text-amber-800 border-amber-300',
    ASIGNADO: 'bg-emerald-100 text-emerald-800 border-emerald-300',
    ENTREGADO: 'bg-teal-100 text-teal-800 border-teal-300',
    CERRADO: 'bg-slate-200 text-slate-700 border-slate-300',
    CANCELADO: 'bg-red-100 text-red-800 border-red-300',
  };

  const pedidosEnBandejaPendientes = pedidosEntrantes.filter(ped => (ped.total_pendiente || 0) > 0);

  const totalPlanos = planos.length;
  const planificadasCount = planos.filter(p => p.estado_diseno === 'PLANIFICADA').length;
  const enDisenoCount = planos.filter(p => p.estado_diseno === 'EN_DISENO').length;
  const liberadosCount = planos.filter(p => p.estado_diseno === 'LIBERADA').length;

  const pedidosEntrantesFiltrados = pedidosEntrantes.filter((ped) => {
    if (!cumpleFiltroBandeja(ped, filtroBandeja)) return false;
    const termino = busquedaBandeja.toLowerCase().trim();
    if (!termino) return true;
    const numPed = (ped.numero_pedido || '').toLowerCase();
    const cliente = (ped.cliente_nombre || '').toLowerCase();
    const prod = (ped.detalle_producto || '').toLowerCase();
    return numPed.includes(termino) || cliente.includes(termino) || prod.includes(termino);
  });

  const planosFiltrados = planos.filter((p) => {
    const termino = busqueda.toLowerCase().trim();
    const codigoPlano = (p.codigo_plano || '').toLowerCase();
    const pedido = (p.numero_pedido || '').toLowerCase();
    const dibujante = (p.dibujante_asignado || '').toLowerCase();
    const coincideBusqueda = codigoPlano.includes(termino) || pedido.includes(termino) || dibujante.includes(termino);

    if (filtroEstado === 'TODOS') return coincideBusqueda;
    const est = p.estado_diseno || 'PLANIFICADA';
    return coincideBusqueda && est === filtroEstado;
  });

  return (
    <div className="p-6 bg-slate-50 min-h-screen space-y-6">
      {/* HEADER PRINCIPAL */}
      <header className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
            <span>📐</span> Ingeniería y Diseño de Planos (PM-02)
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Flujo Lineal Estricto: Abierta ➔ Planificada ➔ En Diseño ➔ Liberada [ISO 9001:2026 / SAP B1]
          </p>
        </div>
        <div className="flex items-center gap-2 self-end sm:self-auto">
          <button 
            onClick={() => { setMensaje({ tipo: '', texto: '' }); cargarPlanosYPedidos(); }}
            className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-lg border border-slate-300 transition flex items-center gap-1.5"
          >
            <span>🔄</span> Recargar
          </button>
        </div>
      </header>

      {/* NOTIFICACIONES */}
      {mensaje.texto && (
        <div className={`p-4 rounded-lg text-sm font-semibold border ${
          mensaje.tipo === 'exito' ? 'bg-emerald-50 text-emerald-800 border-emerald-200' : 'bg-red-50 text-red-800 border-red-200'
        }`}>
          {mensaje.texto}
        </div>
      )}

      {/* BANDEJA DE RECEPCIÓN DESPLEGABLE TIPO TABLA */}
      <div className="bg-white rounded-xl border border-blue-200 shadow-sm overflow-hidden bg-blue-50/10">
        <div 
          onClick={() => setBandejaAbierta(!bandejaAbierta)}
          className="p-4 flex justify-between items-center bg-blue-50/50 hover:bg-blue-100/50 cursor-pointer transition select-none border-b border-blue-100"
        >
          <div className="flex items-center gap-2">
            <span className="text-lg">{bandejaAbierta ? '📂' : '📁'}</span>
            <h2 className="text-sm font-bold text-slate-800">
              BANDEJA DE RECEPCIÓN: Pedidos Comerciales Entrantes
            </h2>
            <span className="text-xs text-slate-500 font-medium ml-1">
              ({bandejaAbierta ? 'Haz clic para ocultar' : 'Haz clic para desplegar'})
            </span>
          </div>

          <div className="flex items-center gap-3">
            <span className="px-2.5 py-1 bg-blue-100 text-blue-800 text-xs font-bold rounded-full border border-blue-200">
              {pedidosEnBandejaPendientes.length} Pedido(s) Pendientes
            </span>
            <span className="text-slate-400 font-bold text-sm">
              {bandejaAbierta ? '▲' : '▼'}
            </span>
          </div>
        </div>

        {bandejaAbierta && (
          <div className="p-4 space-y-3 transition-all">
            <div className="flex justify-between items-center pb-1">
              <span className="text-xs font-bold text-slate-600">Matriz de Distribución de Pedidos Comerciales en OTs</span>
              <input
                type="text"
                placeholder="🔍 Filtrar bandeja por N° Pedido o Cliente..."
                value={busquedaBandeja}
                onChange={(e) => setBusquedaBandeja(e.target.value)}
                className="w-72 p-1.5 border border-slate-300 rounded-lg text-xs bg-white focus:outline-none focus:ring-1 focus:ring-blue-500"
              />
            </div>

            <div className="flex flex-wrap gap-1.5">
              {FILTROS_BANDEJA.map((f) => {
                const n = pedidosEntrantes.filter(p => f.id === 'TODOS' || cumpleFiltroBandeja(p, f.id)).length;
                const activo = filtroBandeja === f.id;
                return (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() => setFiltroBandeja(f.id)}
                    className={`px-2.5 py-1 rounded-full text-[11px] font-bold border transition ${
                      activo ? 'bg-blue-600 text-white border-blue-600' : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    {f.label} <span className={activo ? 'text-blue-100' : 'text-slate-400'}>({n})</span>
                  </button>
                );
              })}
            </div>

            <div className="overflow-x-auto border border-slate-200 rounded-lg bg-white">
              <table className="w-full text-left text-xs text-slate-600 border-collapse">
                <thead>
                  <tr className="bg-slate-100 text-slate-700 font-bold uppercase border-b border-slate-200">
                    <th className="p-3">N° Pedido</th>
                    <th className="p-3">Cliente / Contacto</th>
                    <th className="p-3">Detalle Comercial / Líneas & Piezas</th>
                    <th className="p-3 text-center">Solic. / Asig. / Pend.</th>
                    <th className="p-3">Fecha Compromiso</th>
                    <th className="p-3">Estado</th>
                    <th className="p-3 text-center">Acciones</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {pedidosEntrantesFiltrados.length === 0 ? (
                    <tr>
                      <td colSpan="7" className="p-6 text-center text-slate-400 font-medium">
                        No hay pedidos que coincidan con el filtro de la bandeja.
                      </td>
                    </tr>
                  ) : (
                    pedidosEntrantesFiltrados.map((ped) => (
                      <tr key={ped.id_proyecto} className="hover:bg-slate-50 transition">
                        <td className="p-3 font-mono font-bold whitespace-nowrap">
                          <button
                            type="button"
                            onClick={(e) => handleAbrirExpedientePedido(e, ped.numero_pedido)}
                            className="text-purple-700 hover:text-purple-900 underline bg-purple-50 hover:bg-purple-100 px-2.5 py-1 rounded border border-purple-200 transition"
                          >
                            📋 {ped.numero_pedido || 'PED-S/N'}
                          </button>
                        </td>

                        <td className="p-3 font-medium" onClick={(e) => e.stopPropagation()}>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleAbrirHistoricoClienteUbicacion(ped.cliente_nombre, ped.ubicacion_cliente);
                            }}
                            className="text-slate-800 hover:text-blue-700 text-left font-bold underline cursor-pointer"
                          >
                            🏢 {ped.cliente_nombre || 'Cliente General'}
                          </button>
                          {ped.contacto_nombre && (
                            <div className="text-[10px] text-slate-500 font-medium">👤 {ped.contacto_nombre}</div>
                          )}
                        </td>

                        <td className="p-3 font-medium text-slate-700 max-w-xs">
                          {ped.detalles && ped.detalles.length > 0 ? (
                            <div className="space-y-1">
                              {ped.detalles.map((it, idx) => (
                                <div key={it.detalle_id || idx} className="text-[11px] text-slate-800 font-semibold truncate flex items-center gap-1">
                                  <span className="text-purple-600 font-bold">🧩 Línea {idx + 1}:</span> {it.descripcion || 'Pieza'}
                                  <span className="text-slate-500 font-mono">
                                    ({it.cantidad_asignada}/{it.cantidad_solicitada} {it.unidad || 'UND'})
                                  </span>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <span>{ped.detalle_producto || 'Piezas Mecanizadas Solicitadas'}</span>
                          )}
                        </td>

                        <td className="p-3 text-center font-bold text-blue-900 whitespace-nowrap">
                          <span className="px-2 py-0.5 bg-blue-50 border border-blue-200 rounded">
                            {ped.total_solicitado ?? ped.cantidad ?? 0}
                            {' / '}<span className="text-emerald-700">{ped.total_asignado ?? 0}</span>
                            {' / '}<span className="text-amber-700">{ped.total_pendiente ?? 0}</span>
                          </span>
                          <div className="w-20 h-1.5 bg-slate-200 rounded mx-auto mt-1 overflow-hidden">
                            <div className="h-full bg-emerald-500" style={{ width: `${ped.cobertura_pct || 0}%` }} />
                          </div>
                        </td>

                        <td className="p-3 font-bold text-amber-800 whitespace-nowrap">
                          📅 {ped.fecha_compromiso || 'Sin Fecha'}
                        </td>

                        <td className="p-3 whitespace-nowrap">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${ESTILO_ESTADO_PEDIDO[ped.estado_pedido] || ESTILO_ESTADO_PEDIDO.RECIBIDO}`}>
                            {(ped.estado_pedido || 'RECIBIDO').replaceAll('_', ' ')}
                          </span>
                          {ped.bloqueado && (
                            <div className="text-[10px] font-bold text-red-700 mt-0.5">⛔ OT bloqueada</div>
                          )}
                        </td>

                        <td className="p-3 text-center whitespace-nowrap">
                          <button
                            type="button"
                            disabled={(ped.total_pendiente || 0) === 0}
                            onClick={() => handleAsignarOpDesdePedido(ped)}
                            className="px-3 py-1.5 bg-purple-600 hover:bg-purple-700 disabled:bg-slate-300 disabled:cursor-not-allowed text-white font-bold rounded text-xs transition flex items-center justify-center gap-1 mx-auto shadow-sm"
                          >
                            {(ped.total_asignado || 0) > 0 ? '⚙ Crear otra OT (restante)' : '⚙ Crear / Asignar OT y Planos'}
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* TARJETAS DE ETAPAS INTERACTIVAS */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <button
          type="button"
          onClick={() => setFiltroEstado('TODOS')}
          className={`p-4 rounded-xl border text-left transition-all shadow-sm ${
            filtroEstado === 'TODOS'
              ? 'bg-blue-50/90 border-blue-500 ring-2 ring-blue-400/30 scale-[1.02]'
              : 'bg-white border-slate-200 hover:bg-slate-50'
          }`}
        >
          <span className="text-xs font-bold text-blue-600 uppercase tracking-wide">1. Órdenes Activas</span>
          <p className="text-2xl font-bold text-blue-700 mt-1">{totalPlanos}</p>
          <span className="text-[10px] text-blue-600 font-semibold mt-1 block">🔍 Ver Todas las Órdenes</span>
        </button>

        <button
          type="button"
          onClick={() => setFiltroEstado(filtroEstado === 'PLANIFICADA' ? 'TODOS' : 'PLANIFICADA')}
          className={`p-4 rounded-xl border text-left transition-all shadow-sm ${
            filtroEstado === 'PLANIFICADA'
              ? 'bg-amber-50/90 border-amber-500 ring-2 ring-amber-400/30 scale-[1.02]'
              : 'bg-white border-slate-200 hover:bg-slate-50'
          }`}
        >
          <span className="text-xs font-bold text-amber-600 uppercase tracking-wide">2. Planificadas</span>
          <p className="text-2xl font-bold text-amber-700 mt-1">{planificadasCount}</p>
          <span className="text-[10px] text-amber-600 font-semibold mt-1 block">🔍 Filtrar Planificadas</span>
        </button>

        <button
          type="button"
          onClick={() => setFiltroEstado(filtroEstado === 'EN_DISENO' ? 'TODOS' : 'EN_DISENO')}
          className={`p-4 rounded-xl border text-left transition-all shadow-sm ${
            filtroEstado === 'EN_DISENO'
              ? 'bg-purple-50/90 border-purple-500 ring-2 ring-purple-400/30 scale-[1.02]'
              : 'bg-white border-slate-200 hover:bg-slate-50'
          }`}
        >
          <span className="text-xs font-bold text-purple-600 uppercase tracking-wide">3. En Diseño</span>
          <p className="text-2xl font-bold text-purple-700 mt-1">{enDisenoCount}</p>
          <span className="text-[10px] text-purple-600 font-semibold mt-1 block">🔍 Filtrar En Diseño</span>
        </button>

        <button
          type="button"
          onClick={() => setFiltroEstado(filtroEstado === 'LIBERADA' ? 'TODOS' : 'LIBERADA')}
          className={`p-4 rounded-xl border text-left transition-all shadow-sm ${
            filtroEstado === 'LIBERADA'
              ? 'bg-emerald-50/90 border-emerald-500 ring-2 ring-emerald-400/30 scale-[1.02]'
              : 'bg-white border-slate-200 hover:bg-slate-50'
          }`}
        >
          <span className="text-xs font-bold text-emerald-600 uppercase tracking-wide">4. Liberadas a Planta</span>
          <p className="text-2xl font-bold text-emerald-700 mt-1">{liberadosCount}</p>
          <span className="text-[10px] text-emerald-600 font-semibold mt-1 block">🔍 Filtrar Liberadas</span>
        </button>
      </div>

      {/* TABLA PRINCIPAL DE DISEÑO CON ÓRDENES ABIERTAS */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-3 border-b pb-3">
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-bold text-slate-700">Órdenes Abiertas e Ingeniería</h2>
            {filtroEstado !== 'TODOS' && (
              <span className="px-2 py-0.5 bg-blue-100 text-blue-800 text-[10px] font-bold rounded uppercase">
                Etapa: {filtroEstado}
              </span>
            )}
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 w-full md:w-auto">
            <select
              value={filtroEstado}
              onChange={(e) => setFiltroEstado(e.target.value)}
              className="p-2 border border-slate-300 rounded-lg text-xs bg-slate-50 font-medium text-slate-700 focus:bg-white"
            >
              <option value="TODOS">Todas las Etapas</option>
              <option value="PLANIFICADA">2. PLANIFICADAS</option>
              <option value="EN_DISENO">3. EN DISEÑO</option>
              <option value="LIBERADA">4. LIBERADAS</option>
            </select>

            <input
              type="text"
              placeholder="🔍 Buscar por Plano, Pedido o Diseñador..."
              value={busqueda}
              onChange={(e) => setBusqueda(e.target.value)}
              className="w-full sm:w-72 p-2 border border-slate-300 rounded-lg text-xs bg-slate-50 focus:bg-white"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600 border-collapse">
            <thead>
              <tr className="bg-slate-100 text-slate-700 font-bold uppercase border-b border-slate-200">
                <th className="p-3">Código OT / Área</th>
                <th className="p-3">N° Pedido</th>
                <th className="p-3">Código Plano & Piezas</th>
                <th className="p-3">Tiempo en Estado</th>
                <th className="p-3">Diseñador Asignado</th>
                <th className="p-3">Causa / Razón de Espera</th>
                <th className="p-3">Fechas Clave</th>
                <th className="p-3">Etapa Lineal</th>
                <th className="p-3 text-center">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {planosFiltrados.length === 0 ? (
                <tr>
                  <td colSpan="9" className="p-6 text-center text-slate-400 font-medium">
                    {loading ? 'Cargando planos...' : 'No hay planos técnicos que coincidan con el filtro.'}
                  </td>
                </tr>
              ) : (
                planosFiltrados.map((pl) => {
                  const diasEnEstado = calcularDiasEnEstado(pl.creado_en);
                  const estadoActual = pl.estado_diseno || 'PLANIFICADA';
                  const idxActual = SECUENCIA_ESTADOS.indexOf(estadoActual);

                  return (
                    <tr key={pl.id_plano} className="hover:bg-slate-50 transition">
                      <td className="p-3 font-mono font-bold whitespace-nowrap">
                        <button
                          type="button"
                          onClick={(e) => handleAbrirExpedienteOp(e, pl)}
                          className="text-blue-700 hover:text-blue-900 bg-blue-50 hover:bg-blue-100 px-2 py-1 rounded border border-blue-200 transition"
                        >
                          ⚙ OT-{pl.codigo_op || '4007256'}
                        </button>
                      </td>

                      <td className="p-3 font-mono font-bold whitespace-nowrap">
                        <button
                          type="button"
                          onClick={(e) => handleAbrirExpedientePedido(e, pl.numero_pedido || 'PED-2026-088')}
                          className="text-purple-700 hover:text-purple-900 underline bg-purple-50 hover:bg-purple-100 px-2 py-1 rounded border border-purple-200 transition"
                        >
                          📋 {pl.numero_pedido || 'PED-2026-088'}
                        </button>
                      </td>

                      <td className="p-3 font-mono font-bold text-slate-800">📄 {pl.codigo_plano} ({pl.revision || 'REV-01'})</td>

                      <td className="p-3 font-bold whitespace-nowrap">
                        <span className={`px-2 py-0.5 rounded text-[10px] ${
                          diasEnEstado > 5 ? 'bg-red-100 text-red-800 border border-red-300 font-bold' :
                          diasEnEstado > 2 ? 'bg-amber-100 text-amber-800 border border-amber-300' :
                          'bg-slate-100 text-slate-700'
                        }`}>
                          ⏱️ {diasEnEstado} Días
                        </span>
                      </td>

                      <td className="p-3 font-medium text-slate-800">👤 {pl.dibujante_asignado || 'Ing. Carlos Ruiz'}</td>

                      {/* COLUMNA DE CAUSA DE ESPERA CON DESPLEGABLE DIRECTO DESDE LA TABLA */}
                      <td className="p-3 font-medium text-slate-700 max-w-xs">
                        <select
                          value={pl.causa_espera || 'RESUELTA'}
                          onChange={(e) => handleCambiarCausaEsperaTabla(pl, e.target.value)}
                          className={`p-1 rounded text-[10px] font-bold border focus:outline-none cursor-pointer w-full truncate ${
                            !pl.causa_espera 
                              ? 'bg-emerald-50 text-emerald-800 border-emerald-300' 
                              : 'bg-amber-50 text-amber-900 border-amber-300'
                          }`}
                        >
                          <option value="RESUELTA">✓ Sin demoras / Resuelta</option>
                          {OPCIONES_CAUSA_ESPERA.map((opcion, idx) => (
                            <option key={idx} value={opcion}>
                              ⚠️ {opcion}
                            </option>
                          ))}
                        </select>
                      </td>

                      <td className="p-3 font-medium text-slate-800 text-[11px] whitespace-nowrap space-y-0.5">
                        <div>📅 Prog: <strong>{pl.fecha_inicio_programada || 'Sin Fecha'}</strong></div>
                        <div className="text-blue-800">🏁 Límite: <strong>{pl.fecha_entrega_produccion || '2026-10-15'}</strong></div>
                      </td>

                      <td className="p-3 whitespace-nowrap">
                        <select
                          value={estadoActual}
                          onChange={(e) => handleCambiarEtapaOrden(pl, e.target.value)}
                          className={`p-1 rounded text-[10px] font-bold border focus:outline-none cursor-pointer ${
                            estadoActual === 'LIBERADA' ? 'bg-emerald-100 text-emerald-800 border-emerald-300' :
                            estadoActual === 'EN_DISENO' ? 'bg-purple-100 text-purple-800 border-purple-300' :
                            estadoActual === 'PLANIFICADA' ? 'bg-amber-100 text-amber-800 border-amber-300' :
                            'bg-blue-100 text-blue-800 border-blue-300'
                          }`}
                        >
                          {SECUENCIA_ESTADOS.map((est, idx) => (
                            <option 
                              key={est} 
                              value={est} 
                              disabled={idx !== idxActual + 1 && idx !== idxActual}
                            >
                              {idx + 1}. {est} {idx < idxActual ? '🔒 (Completado)' : idx > idxActual + 1 ? '🔒 (Bloqueado)' : ''}
                            </option>
                          ))}
                        </select>
                      </td>

                      <td className="p-3 text-center whitespace-nowrap">
                        <button
                          type="button"
                          onClick={(e) => handleAbrirExpedienteOp(e, pl)}
                          className="px-2.5 py-1 font-semibold rounded text-[11px] bg-slate-700 text-white hover:bg-slate-800 shadow-sm transition"
                        >
                          👁️ Ver Expediente
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL 1: EXPEDIENTE CON JERARQUÍA PEDIDO ➔ LÍNEAS ➔ OTs */}
      {modalPedidoAbierto && pedidoSeleccionado && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex justify-center items-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-4xl w-full p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-start border-b pb-3">
              <div>
                <span className="px-2 py-0.5 bg-purple-100 text-purple-800 text-[10px] font-bold rounded uppercase">
                  Expediente Comercial Agrupador [ISO 9001:2026 / SAP B1]
                </span>
                <h3 className="text-xl font-bold text-slate-800 mt-1">
                  Pedido N°: <span className="text-purple-700 font-mono">{pedidoSeleccionado.numero_pedido}</span>
                </h3>
              </div>
              <button onClick={() => setModalPedidoAbierto(false)} className="text-slate-400 hover:text-slate-600 font-bold text-lg">✕</button>
            </div>

            <div className="text-xs bg-slate-50 p-3 rounded-lg border border-slate-200 grid grid-cols-2 gap-2">
              <p><strong>Cliente / Razón Social:</strong> {pedidoSeleccionado.cliente_nombre}</p>
              <p><strong>Contacto Cliente:</strong> 👤 {pedidoSeleccionado.contacto_nombre}</p>
              <p><strong>Ubicación Planta:</strong> {pedidoSeleccionado.ubicacion_cliente}</p>
              <p><strong>Fecha Compromiso Cliente:</strong> <span className="font-bold text-slate-800">📅 {pedidoSeleccionado.fecha_compromiso}</span></p>
              <p className="col-span-2"><strong>Requisitos Técnicos Generales:</strong> {pedidoSeleccionado.requisitos_cliente}</p>
            </div>

            {/* VISTA ÁRBOL DE JERARQUÍA LÍNEAS / PIEZAS ➔ OTs */}
            <div className="space-y-3 border p-3 rounded-lg bg-slate-50/50">
              <h4 className="font-bold text-slate-800 text-xs flex items-center gap-1">
                <span>📦</span> Desglose de Líneas / Piezas y Órdenes de Trabajo (OTs) Asignadas
              </h4>
              
              {pedidoSeleccionado.lineas.map((linea, idx) => (
                <div key={idx} className="ml-2 pl-3 border-l-2 border-purple-500 space-y-2 bg-white p-3 rounded-lg border border-slate-200 shadow-sm">
                  <div className="font-bold text-slate-800 text-xs flex items-center justify-between border-b pb-1">
                    <span className="text-purple-700">🧩 Línea {linea.numero_linea || idx + 1}: {linea.detalle_pieza} ({linea.cantidad} UND)</span>
                    <span className="text-[10px] text-slate-500 font-mono bg-slate-100 px-2 py-0.5 rounded">Material: {linea.material_requerido || 'ASTM A105'}</span>
                  </div>

                  <div className="ml-2 space-y-1">
                    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wide">Órdenes de Trabajo (OTs) Generadas:</span>
                    {linea.ordenes && linea.ordenes.length > 0 ? (
                      linea.ordenes.map((ot, otIdx) => (
                        <div key={otIdx} className="text-[11px] flex items-center justify-between bg-blue-50/60 p-2 rounded border border-blue-200">
                          <span className="font-mono font-bold text-blue-800">⚙ OT-{ot.codigo_op} ({ot.unidad_planta})</span>
                          <span className="font-mono text-slate-700">📄 {ot.codigo_plano} ({ot.revision || 'REV-01'})</span>
                          <span className="text-slate-600 font-medium">👤 {ot.dibujante_asignado || 'Ing. Carlos Ruiz'}</span>
                          <span className={`px-2 py-0.5 rounded text-[9px] font-bold ${
                            ot.estado_diseno === 'LIBERADA' ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' : 'bg-amber-100 text-amber-800 border border-amber-300'
                          }`}>
                            {ot.estado_diseno || 'PLANIFICADA'}
                          </span>
                        </div>
                      ))
                    ) : (
                      <p className="text-[11px] text-slate-400 italic">No hay OTs asignadas directamente a esta línea técnica.</p>
                    )}
                  </div>
                </div>
              ))}
            </div>

            <div className="flex justify-end border-t pt-3">
              <button onClick={() => setModalPedidoAbierto(false)} className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded text-xs transition">
                Cerrar Expediente
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: EXPEDIENTE DETALLADO DE OT Y SUS PIEZAS */}
      {modalOpAbierto && opSeleccionada && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex justify-center items-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-3xl w-full p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-start border-b pb-3">
              <div>
                <span className="px-2 py-0.5 bg-blue-100 text-blue-800 text-[10px] font-bold rounded uppercase">
                  Ficha Técnica de OT e Ingeniería [PM-02 / ISO 9001:2026]
                </span>
                <h3 className="text-xl font-bold text-slate-800 mt-1">
                  Orden de Trabajo: <span className="text-blue-700 font-mono">OT-{opSeleccionada.codigo_op || '4007256'}</span>
                </h3>
              </div>
              <button onClick={() => setModalOpAbierto(false)} className="text-slate-400 hover:text-slate-600 font-bold text-lg">✕</button>
            </div>

            <div className="text-xs bg-slate-50 p-4 rounded-lg border border-slate-200 grid grid-cols-2 gap-3">
              <p><strong>N° Pedido:</strong> <span className="font-mono text-purple-700 font-bold">{opSeleccionada.numero_pedido || 'PED-2026-088'}</span></p>
              <p><strong>Código Plano Técnico:</strong> <span className="font-mono text-blue-700 font-bold">{opSeleccionada.codigo_plano}</span></p>
              <p><strong>Versión / Revisión:</strong> {opSeleccionada.revision || 'REV-01'}</p>
              <p><strong>Diseñador Responsable:</strong> 👤 {opSeleccionada.dibujante_asignado || 'Ing. Carlos Ruiz'}</p>
              <p><strong>Unidad de Planta Destino:</strong> 🏭 {opSeleccionada.unidad_planta || 'Mecanizados'}</p>
              <p><strong>Tiempo Estimado Diseño:</strong> <span className="font-bold text-blue-900">{opSeleccionada.tiempo_estimado_valor || 4} {opSeleccionada.tiempo_estimado_unidad || 'HORAS'}</span></p>
              <p><strong>Fecha Límite Producción:</strong> <span className="font-bold text-slate-800">📅 {opSeleccionada.fecha_entrega_produccion || '2026-10-15'}</span></p>
              <p className="col-span-2"><strong>Materia Prima / Insumo Requerido (BOM):</strong> {opSeleccionada.material_requerido || 'Acero ASTM A105'}</p>
              <p className="col-span-2 font-bold text-amber-800"><strong>Causa / Razón de Espera:</strong> {opSeleccionada.causa_espera || 'Sin observaciones de demora / Resuelta'}</p>
            </div>

            {opSeleccionada.archivo_url && (
              <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg flex justify-between items-center text-xs">
                <span className="font-bold text-blue-900">📄 Archivo de Plano Digital PDF Disponible</span>
                <a href={opSeleccionada.archivo_url} target="_blank" rel="noreferrer" className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded shadow-sm">
                  Abrir Plano PDF
                </a>
              </div>
            )}

            <div className="flex justify-end border-t pt-3">
              <button onClick={() => setModalOpAbierto(false)} className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded text-xs transition">
                Cerrar Ficha Técnica
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 3: HISTÓRICO DE TRABAJOS DE SOLO LECTURA POR CLIENTE Y SEDE (ESTILO CRONOGRAMA) */}
      {modalHistoricoClienteAbierto && clienteHistoricoSeleccionado && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex justify-center items-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-5xl w-full p-6 space-y-4 max-h-[92vh] overflow-y-auto">
            <div className="flex justify-between items-start border-b pb-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 bg-slate-800 text-white text-[10px] font-bold rounded uppercase">
                    🔒 CONSULTA DE SOLO LECTURA [AUDITORÍA SGI ISO 9001:2026]
                  </span>
                </div>
                <h3 className="text-xl font-bold text-slate-800 mt-1">
                  Histórico de Trabajos: <span className="text-blue-700">{clienteHistoricoSeleccionado.cliente_nombre}</span>
                </h3>
                <p className="text-xs text-slate-500">
                  Sede / Planta de Entrega: <strong>📍 {clienteHistoricoSeleccionado.ubicacion_cliente}</strong>
                </p>
              </div>
              <button onClick={() => setModalHistoricoClienteAbierto(false)} className="text-slate-400 hover:text-slate-600 font-bold text-lg">✕</button>
            </div>

            <div className="overflow-x-auto border border-slate-200 rounded-lg">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-800 text-white font-bold uppercase text-[11px]">
                    <th className="p-2.5">N° Pedido</th>
                    <th className="p-2.5">Código OT</th>
                    <th className="p-2.5">Plano Técnico</th>
                    <th className="p-2.5">Detalle / Pieza</th>
                    <th className="p-2.5 text-center">Cantidad</th>
                    <th className="p-2.5">Planta</th>
                    <th className="p-2.5">Fecha Entrega</th>
                    <th className="p-2.5 text-center">Estado SGI</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 text-slate-700">
                  {clienteHistoricoSeleccionado.ordenes.length === 0 ? (
                    <tr>
                      <td colSpan="8" className="p-6 text-center text-slate-400 font-medium italic">
                        No hay trabajos históricos registrados previamente para esta sede.
                      </td>
                    </tr>
                  ) : (
                    clienteHistoricoSeleccionado.ordenes.map((o, idx) => (
                      <tr key={idx} className="hover:bg-slate-50">
                        <td className="p-2.5 font-mono font-bold text-purple-700">📋 {o.numero_pedido || 'PED-S/N'}</td>
                        <td className="p-2.5 font-mono font-bold text-blue-700">⚙ OT-{o.codigo_op || '4007256'}</td>
                        <td className="p-2.5 font-mono font-bold text-slate-800">📄 {o.codigo_plano}</td>
                        <td className="p-2.5 font-medium text-slate-800">{o.material_requerido || 'Pieza Mecanizada'}</td>
                        <td className="p-2.5 text-center font-bold text-slate-800">1 UND</td>
                        <td className="p-2.5 font-bold text-slate-700">🏭 {o.unidad_planta || 'Mecanizados'}</td>
                        <td className="p-2.5 font-bold text-slate-800">📅 {o.fecha_entrega_produccion || '2026-10-15'}</td>
                        <td className="p-2.5 text-center">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                            {o.estado_diseno || 'LIBERADA'}
                          </span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            <div className="flex justify-end border-t pt-3">
              <button onClick={() => setModalHistoricoClienteAbierto(false)} className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded text-xs transition">
                Cerrar Cronograma
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 4: CREACIÓN Y ESTRUCTURACIÓN DE OT CON SELECCIÓN DE CAUSA / RESUELTA */}
      {modalNuevoPlanoAbierto && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex justify-center items-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-5xl w-full p-6 space-y-4 max-h-[92vh] overflow-y-auto">
            <div className="flex justify-between items-start border-b pb-3">
              <div>
                <span className="px-2 py-0.5 bg-blue-100 text-blue-800 text-[10px] font-bold rounded uppercase">
                  Apertura de Orden de Diseño [PM-02 / ISO 9001:2026]
                </span>
                <h3 className="text-xl font-bold text-slate-800 mt-1">
                  Estructurar y Crear Orden de Trabajo (OT)
                </h3>
              </div>
              <button onClick={() => setModalNuevoPlanoAbierto(false)} className="text-slate-400 hover:text-slate-600 font-bold text-lg">✕</button>
            </div>

            <form onSubmit={handleCrearOrdenDiseno} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">N° Pedido</label>
                  <input
                    type="text"
                    disabled
                    value={nuevoPlano.numero_pedido || 'PED-2026-088'}
                    className="w-full p-2 border border-slate-300 rounded font-mono font-bold text-purple-700 bg-slate-100 cursor-not-allowed"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Código OT (Planta) *</label>
                  <input
                    type="text"
                    required
                    placeholder="Ej. 4007256"
                    value={nuevoPlano.codigo_op}
                    onChange={(e) => setNuevoPlano({ ...nuevoPlano, codigo_op: e.target.value })}
                    className="w-full p-2 border border-blue-400 rounded font-mono font-bold text-blue-900 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Unidad de Planta Destino *</label>
                  <select
                    value={nuevoPlano.unidad_planta}
                    onChange={(e) => handleCambioUnidadPlanta(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded font-bold text-slate-800 bg-white"
                  >
                    <option value="Mecanizados">⚙ Mecanizados (Rango 4xxxxxx)</option>
                    <option value="Metalistería">🔩 Metalistería / Corte (Rango 1xxxxxx)</option>
                    <option value="Servicios">🛠 Servicios / Mantenimiento (Rango 3xxxxxx)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Etapa Inicial Obligatoria</label>
                  <input
                    type="text"
                    disabled
                    value="2. PLANIFICADA"
                    className="w-full p-2 border border-amber-300 rounded font-bold text-amber-900 bg-amber-50 cursor-not-allowed"
                  />
                </div>
              </div>

              {/* PROGRAMACIÓN DE TIEMPO Y FECHAS CRÍTICAS */}
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 bg-blue-50/40 p-3 rounded-lg border border-blue-200">
                <div>
                  <label className="block font-bold text-slate-800 mb-1">⏱️ Tiempo Estimado Diseño *</label>
                  <div className="flex gap-1">
                    <input
                      type="number"
                      min="1"
                      required
                      value={nuevoPlano.tiempo_estimado_valor}
                      onChange={(e) => setNuevoPlano({ ...nuevoPlano, tiempo_estimado_valor: parseInt(e.target.value) || 1 })}
                      className="w-1/2 p-1.5 border border-slate-300 rounded font-bold text-center text-slate-800 bg-white"
                    />
                    <select
                      value={nuevoPlano.tiempo_estimado_unidad}
                      onChange={(e) => setNuevoPlano({ ...nuevoPlano, tiempo_estimado_unidad: e.target.value })}
                      className="w-1/2 p-1.5 border border-slate-300 rounded font-bold text-slate-800 bg-white"
                    >
                      <option value="HORAS">Horas</option>
                      <option value="DIAS">Días</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-slate-800 mb-1">📅 Fecha Inicio Programada *</label>
                  <input
                    type="date"
                    required
                    value={nuevoPlano.fecha_inicio_programada}
                    onChange={(e) => setNuevoPlano({ ...nuevoPlano, fecha_inicio_programada: e.target.value })}
                    className="w-full p-1.5 border border-slate-300 rounded font-bold text-slate-800 bg-white"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-800 mb-1">📅 Fecha Compromiso Cliente *</label>
                  <input
                    type="date"
                    required
                    value={nuevoPlano.fecha_entrega_cliente}
                    onChange={(e) => setNuevoPlano({ ...nuevoPlano, fecha_entrega_cliente: e.target.value })}
                    className="w-full p-1.5 border border-slate-300 rounded font-bold text-slate-800 bg-white"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-800 mb-1">🏁 Fecha Límite Producción *</label>
                  <input
                    type="date"
                    required
                    value={nuevoPlano.fecha_entrega_produccion}
                    onChange={(e) => setNuevoPlano({ ...nuevoPlano, fecha_entrega_produccion: e.target.value })}
                    className="w-full p-1.5 border border-blue-300 rounded font-bold text-blue-900 bg-white"
                  />
                </div>
              </div>

              {/* GRILLA DE PIEZAS DESGLOSADAS DESDE VENTAS */}
              <div className="border border-slate-200 rounded-xl p-3 bg-slate-50/50 space-y-3">
                <div className="flex justify-between items-center border-b pb-2">
                  <h4 className="font-bold text-slate-800 flex items-center gap-1.5 text-xs">
                    <span>📄</span> Desglose de Piezas Pertenecientes al Pedido Comercial (BOM)
                  </h4>
                  <span className="text-[11px] text-slate-500 font-semibold italic">
                    Líneas con cantidad pendiente (use 0 para dejar una línea fuera de esta OT)
                  </span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs bg-white border border-slate-200 rounded-lg overflow-hidden">
                    <thead className="bg-slate-100 text-slate-700 font-bold border-b">
                      <tr>
                        <th className="p-2.5 w-10 text-center">#</th>
                        <th className="p-2.5 w-40">Código Plano *</th>
                        <th className="p-2.5 w-20">Revisión</th>
                        <th className="p-2.5">Nombre / Detalle de la Pieza *</th>
                        <th className="p-2.5 w-28 text-center">Cant. en esta OT / Pend.</th>
                        <th className="p-2.5">Materia Prima Requerida (BOM)</th>
                        <th className="p-2.5">URL / Archivo PDF del Plano</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {nuevoPlano.piezas.map((p, idx) => (
                        <tr key={p.id} className="hover:bg-slate-50">
                          <td className="p-2 text-center font-bold text-slate-400">{idx + 1}</td>
                          
                          <td className="p-2">
                            <input
                              type="text"
                              required
                              placeholder="PLN-PED-2026-075-A"
                              value={p.codigo_plano}
                              onChange={(e) => handleCambioPieza(p.id, 'codigo_plano', e.target.value)}
                              className="w-full p-1.5 border border-slate-300 rounded font-mono font-bold text-blue-700 focus:outline-none focus:ring-1 focus:ring-blue-500"
                            />
                          </td>

                          <td className="p-2">
                            <input
                              type="text"
                              value={p.revision}
                              onChange={(e) => handleCambioPieza(p.id, 'revision', e.target.value)}
                              className="w-full p-1.5 border border-slate-300 rounded text-center font-bold focus:outline-none focus:ring-1 focus:ring-blue-500"
                            />
                          </td>

                          <td className="p-2">
                            <input
                              type="text"
                              required
                              value={p.detalle_pieza}
                              onChange={(e) => handleCambioPieza(p.id, 'detalle_pieza', e.target.value)}
                              className="w-full p-1.5 border border-slate-300 rounded font-medium text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500"
                            />
                          </td>

                          <td className="p-2">
                            <div className="flex items-center gap-1">
                              <input
                                type="number"
                                min="0"
                                max={p.cantidad_pendiente ?? undefined}
                                value={p.cantidad}
                                onChange={(e) => handleCambioPieza(p.id, 'cantidad', parseInt(e.target.value) || 0)}
                                className="w-full p-1.5 border border-slate-300 rounded text-center font-bold focus:outline-none focus:ring-1 focus:ring-blue-500"
                              />
                              {p.cantidad_pendiente !== undefined && (
                                <span className="text-[10px] text-amber-700 font-bold whitespace-nowrap">/ {p.cantidad_pendiente}</span>
                              )}
                            </div>
                          </td>

                          <td className="p-2">
                            <input
                              type="text"
                              placeholder="Acero ASTM A105"
                              value={p.material_requerido}
                              onChange={(e) => handleCambioPieza(p.id, 'material_requerido', e.target.value)}
                              className="w-full p-1.5 border border-slate-300 rounded text-slate-700 focus:outline-none focus:ring-1 focus:ring-blue-500"
                            />
                          </td>

                          <td className="p-2">
                            <input
                              type="text"
                              placeholder="http://127.0.0.1:8000/static/planos/PLN-001.pdf"
                              value={p.archivo_url || ''}
                              onChange={(e) => handleCambioPieza(p.id, 'archivo_url', e.target.value)}
                              className="w-full p-1.5 border border-blue-200 bg-blue-50/30 rounded text-blue-800 font-mono text-[11px] focus:outline-none focus:ring-1 focus:ring-blue-500"
                            />
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* DESPLEGABLE CON OPCIÓN DE RESUELTA / LEVANTADA */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Diseñador Responsable *</label>
                  <input
                    type="text"
                    required
                    placeholder="Ing. Carlos Ruiz"
                    value={nuevoPlano.dibujante_asignado}
                    onChange={(e) => setNuevoPlano({ ...nuevoPlano, dibujante_asignado: e.target.value })}
                    className="w-full p-2 border border-slate-300 rounded text-slate-800 font-medium"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Causa / Razón de Espera (Inicial)</label>
                  <select
                    value={nuevoPlano.causa_espera || ''}
                    onChange={(e) => setNuevoPlano({ ...nuevoPlano, causa_espera: e.target.value })}
                    className="w-full p-2 border border-amber-300 rounded text-amber-900 font-bold bg-amber-50"
                  >
                    <option value="">Sin demoras / Restricción resuelta</option>
                    {OPCIONES_CAUSA_ESPERA.map((opcion, idx) => (
                      <option key={idx} value={opcion}>{opcion}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="flex justify-end gap-2 border-t pt-3">
                <button
                  type="button"
                  onClick={() => setModalNuevoPlanoAbierto(false)}
                  className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold rounded"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded shadow-sm flex items-center gap-1.5"
                >
                  {loading ? 'Guardando...' : '💾 Crear Orden en Estado PLANIFICADA'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}