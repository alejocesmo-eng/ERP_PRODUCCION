# 04_CODIGO/BACKEND/app/api/v1/proyectos.py
import logging
from collections import defaultdict
from typing import List, Optional
from uuid import UUID
from datetime import datetime, date

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from pydantic import BaseModel, Field

from app.db.database import get_db
from app.db.models import Proyecto, PedidoDetalle, OTDetalle, Plano
from app.services.asignacion import (
    ESTADO_OT_ANULADA,
    cantidades_asignadas,
    estado_asignacion_linea,
    estado_pedido,
)

router = APIRouter()
audit = logging.getLogger("sgi.audit")

# --- SCHEMAS PYDANTIC ---

class OTDetalleResponse(BaseModel):
    ot_detalle_id: UUID
    ot_id: UUID
    detalle_id: UUID
    cantidad_asignada: int
    codigo_op: Optional[str] = None
    estado_ot: Optional[str] = None
    causa_espera: Optional[str] = None

    class Config:
        from_attributes = True

class PedidoDetalleCreate(BaseModel):
    codigo_producto: Optional[str] = None
    descripcion: str = Field(..., description="Nombre de la pieza, conjunto, servicio, trabajo o producto")
    tipo: Optional[str] = "PIEZA"
    cantidad_solicitada: int = Field(1, ge=1)
    unidad: Optional[str] = "UND"
    fecha_requerida: Optional[date] = None
    prioridad: Optional[str] = "MEDIA"
    observaciones: Optional[str] = None

class ProyectoCreate(BaseModel):
    numero_pedido: str = Field(..., description="N° Pedido Comercial Agrupador")
    codigo_proyecto: Optional[str] = None
    cliente_nombre: str
    contacto_nombre: Optional[str] = None
    contacto_telefono: Optional[str] = None
    contacto_email: Optional[str] = None
    ubicacion_cliente: Optional[str] = None
    requisitos_cliente: str
    fecha_compromiso: Optional[date] = None
    detalles: Optional[List[PedidoDetalleCreate]] = Field(default_factory=list)

class ProyectoUpdate(BaseModel):
    # 'cantidad' y 'detalle_producto' ya no se editan a mano: se derivan de PEDIDO_DETALLE.
    numero_pedido: Optional[str] = None
    codigo_proyecto: Optional[str] = None
    cliente_nombre: Optional[str] = None
    contacto_nombre: Optional[str] = None
    contacto_telefono: Optional[str] = None
    contacto_email: Optional[str] = None
    ubicacion_cliente: Optional[str] = None
    requisitos_cliente: Optional[str] = None
    fecha_compromiso: Optional[date] = None
    motivo_cambio: Optional[str] = Field(None, description="Obligatorio si el pedido ya tiene OTs activas")

class PedidoDetalleResponse(BaseModel):
    detalle_id: UUID
    codigo_producto: Optional[str] = None
    descripcion: str
    tipo: str
    cantidad_solicitada: int
    unidad: str
    cantidad_asignada: int
    cantidad_pendiente: int
    estado_asignacion: str
    fecha_requerida: Optional[date] = None
    prioridad: str
    observaciones: Optional[str] = None
    ot_detalles: List[OTDetalleResponse] = Field(default_factory=list)

    class Config:
        from_attributes = True

class ProyectoResponse(BaseModel):
    id_proyecto: UUID
    codigo_proyecto: str
    numero_pedido: Optional[str] = None
    cliente_nombre: str
    contacto_nombre: Optional[str] = None
    contacto_telefono: Optional[str] = None
    contacto_email: Optional[str] = None
    ubicacion_cliente: Optional[str] = None
    cantidad: Optional[int] = 1
    detalle_producto: Optional[str] = None
    requisitos_cliente: str
    confirmado: bool
    fecha_compromiso: Optional[date] = None
    creado_en: datetime
    # --- calculados (PDF puntos 5 y 6) ---
    estado_pedido: str = "RECIBIDO"
    total_solicitado: int = 0
    total_asignado: int = 0
    total_pendiente: int = 0
    cobertura_pct: int = 0
    bloqueado: bool = False
    detalles: List[PedidoDetalleResponse] = Field(default_factory=list)

    class Config:
        from_attributes = True

# --- SERIALIZADOR (no muta objetos ORM) ---

def _construir_respuestas(db: Session, proyectos: List[Proyecto]) -> List[ProyectoResponse]:
    detalle_ids = [d.detalle_id for p in proyectos for d in p.detalles]
    asignadas = cantidades_asignadas(db, detalle_ids)

    # Todas las asignaciones (incluye OTs anuladas, para conservar historial)
    por_detalle = defaultdict(list)
    if detalle_ids:
        filas = (
            db.query(OTDetalle, Plano.codigo_op, Plano.estado_diseno, Plano.causa_espera)
            .join(Plano, Plano.id_plano == OTDetalle.ot_id)
            .filter(OTDetalle.detalle_id.in_(detalle_ids))
            .all()
        )
        for ot_det, codigo_op, estado_ot, causa in filas:
            por_detalle[ot_det.detalle_id].append(OTDetalleResponse(
                ot_detalle_id=ot_det.ot_detalle_id,
                ot_id=ot_det.ot_id,
                detalle_id=ot_det.detalle_id,
                cantidad_asignada=ot_det.cantidad_asignada,
                codigo_op=codigo_op,
                estado_ot=estado_ot,
                causa_espera=causa,
            ))

    respuestas = []
    for p in proyectos:
        num_ped = p.numero_pedido or p.codigo_proyecto or "S/P"
        lineas, detalles_resp, bloqueado = [], [], False

        for det in p.detalles:
            sol = det.cantidad_solicitada or 0
            asig = asignadas.get(det.detalle_id, 0)
            lineas.append((sol, asig))
            ots = por_detalle.get(det.detalle_id, [])
            if any(o.causa_espera and o.estado_ot != ESTADO_OT_ANULADA for o in ots):
                bloqueado = True
            detalles_resp.append(PedidoDetalleResponse(
                detalle_id=det.detalle_id,
                codigo_producto=det.codigo_producto,
                descripcion=det.descripcion,
                tipo=det.tipo or "PIEZA",
                cantidad_solicitada=sol,
                unidad=det.unidad or "UND",
                cantidad_asignada=asig,
                cantidad_pendiente=max(sol - asig, 0),
                estado_asignacion=estado_asignacion_linea(sol, asig),
                fecha_requerida=det.fecha_requerida,
                prioridad=det.prioridad or "MEDIA",
                observaciones=det.observaciones,
                ot_detalles=ots,
            ))

        tot_sol = sum(s for s, _ in lineas)
        tot_asig = sum(min(a, s) for s, a in lineas)
        respuestas.append(ProyectoResponse(
            id_proyecto=p.id_proyecto,
            codigo_proyecto=p.codigo_proyecto or f"PED-{num_ped}",
            numero_pedido=num_ped,
            cliente_nombre=p.cliente_nombre,
            contacto_nombre=p.contacto_nombre,
            contacto_telefono=p.contacto_telefono,
            contacto_email=p.contacto_email,
            ubicacion_cliente=p.ubicacion_cliente,
            cantidad=p.cantidad,
            detalle_producto=p.detalle_producto,
            requisitos_cliente=p.requisitos_cliente,
            confirmado=bool(p.confirmado),
            fecha_compromiso=p.fecha_compromiso,
            creado_en=p.creado_en,
            estado_pedido=estado_pedido(bool(p.confirmado), lineas),
            total_solicitado=tot_sol,
            total_asignado=tot_asig,
            total_pendiente=max(tot_sol - tot_asig, 0),
            cobertura_pct=round(100 * tot_asig / tot_sol) if tot_sol else 0,
            bloqueado=bloqueado,
            detalles=detalles_resp,
        ))
    return respuestas

# --- ENDPOINTS ---

@router.get("/", response_model=List[ProyectoResponse])
def listar_proyectos(db: Session = Depends(get_db)):
    """PM-01: Pedidos con líneas, cantidades asignadas/pendientes y estado automático.
    Devuelve TODOS los pedidos: el filtrado de la bandeja se hace en el cliente por estado_pedido."""
    proyectos_db = db.query(Proyecto).order_by(Proyecto.creado_en.desc()).all()
    return _construir_respuestas(db, proyectos_db)

@router.get("/{id_proyecto}", response_model=ProyectoResponse)
def obtener_proyecto(id_proyecto: UUID, db: Session = Depends(get_db)):
    proyecto = db.query(Proyecto).filter(Proyecto.id_proyecto == id_proyecto).first()
    if not proyecto:
        raise HTTPException(status_code=404, detail="Pedido comercial no encontrado.")
    return _construir_respuestas(db, [proyecto])[0]

@router.post("/", response_model=ProyectoResponse, status_code=status.HTTP_201_CREATED)
def crear_proyecto(proyecto_in: ProyectoCreate, db: Session = Depends(get_db)):
    """PM-01: Radicar Pedido Comercial creando sus registros en PEDIDO_DETALLE."""
    codigo_ref = proyecto_in.codigo_proyecto or f"PED-{proyecto_in.numero_pedido}"

    detalle_resumen = "Elementos varios"
    cant_total = 1
    if proyecto_in.detalles:
        detalle_resumen = " | ".join(f"{d.cantidad_solicitada}x {d.descripcion}" for d in proyecto_in.detalles)
        cant_total = sum(d.cantidad_solicitada for d in proyecto_in.detalles)

    nuevo_proyecto = Proyecto(
        codigo_proyecto=codigo_ref,
        numero_pedido=proyecto_in.numero_pedido,
        cliente_nombre=proyecto_in.cliente_nombre,
        contacto_nombre=proyecto_in.contacto_nombre,
        contacto_telefono=proyecto_in.contacto_telefono,
        contacto_email=proyecto_in.contacto_email,
        ubicacion_cliente=proyecto_in.ubicacion_cliente,
        fecha_compromiso=proyecto_in.fecha_compromiso,
        requisitos_cliente=proyecto_in.requisitos_cliente,
        confirmado=False,
        cantidad=cant_total,
        detalle_producto=detalle_resumen,
    )
    db.add(nuevo_proyecto)
    db.flush()

    for det in proyecto_in.detalles or []:
        db.add(PedidoDetalle(
            pedido_id=nuevo_proyecto.id_proyecto,
            codigo_producto=det.codigo_producto,
            descripcion=det.descripcion,
            tipo=det.tipo or "PIEZA",
            cantidad_solicitada=det.cantidad_solicitada,
            unidad=det.unidad or "UND",
            cantidad_asignada=0,
            cantidad_pendiente=det.cantidad_solicitada,
            fecha_requerida=det.fecha_requerida or proyecto_in.fecha_compromiso,
            prioridad=det.prioridad or "MEDIA",
            observaciones=det.observaciones,
        ))

    db.commit()
    db.refresh(nuevo_proyecto)
    audit.info("PEDIDO_CREADO pedido=%s cliente=%s lineas=%d",
               proyecto_in.numero_pedido, proyecto_in.cliente_nombre, len(proyecto_in.detalles or []))
    return _construir_respuestas(db, [nuevo_proyecto])[0]

@router.patch("/{id_proyecto}", response_model=ProyectoResponse)
def actualizar_proyecto(id_proyecto: UUID, proyecto_up: ProyectoUpdate, db: Session = Depends(get_db)):
    proyecto = db.query(Proyecto).filter(Proyecto.id_proyecto == id_proyecto).first()
    if not proyecto:
        raise HTTPException(status_code=404, detail="Pedido comercial no encontrado.")

    datos = proyecto_up.dict(exclude_unset=True)
    motivo = (datos.pop("motivo_cambio", None) or "").strip()
    datos = {k: v for k, v in datos.items() if v is not None and hasattr(proyecto, k)}

    # Control de cambios (PDF punto 9): si ya hay OTs activas, exigir motivo y dejar rastro.
    if datos:
        ya_asignado = _construir_respuestas(db, [proyecto])[0].total_asignado > 0
        if ya_asignado and len(motivo) < 5:
            raise HTTPException(
                status_code=409,
                detail="El pedido ya tiene OTs activas: indique 'motivo_cambio' (mín. 5 caracteres) para modificarlo.",
            )
        for campo, valor in datos.items():
            audit.info("PEDIDO_CAMBIO pedido=%s campo=%s anterior=%r nuevo=%r motivo=%r",
                       proyecto.numero_pedido, campo, getattr(proyecto, campo), valor, motivo)
            setattr(proyecto, campo, valor)

    db.commit()
    db.refresh(proyecto)
    return _construir_respuestas(db, [proyecto])[0]

@router.patch("/{id_proyecto}/confirmar", response_model=ProyectoResponse)
def confirmar_proyecto(id_proyecto: UUID, db: Session = Depends(get_db)):
    proyecto = db.query(Proyecto).filter(Proyecto.id_proyecto == id_proyecto).first()
    if not proyecto:
        raise HTTPException(status_code=404, detail="Pedido no encontrado.")

    proyecto.confirmado = True
    db.commit()
    db.refresh(proyecto)
    audit.info("PEDIDO_CONFIRMADO pedido=%s", proyecto.numero_pedido)
    return _construir_respuestas(db, [proyecto])[0]
