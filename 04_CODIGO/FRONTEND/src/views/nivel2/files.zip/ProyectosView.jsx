import React, { useState, useEffect } from 'react';
import API from '../../services/api';

export default function ProyectosView() {
  const [proyectos, setProyectos] = useState([]);
  const [loading, setLoading] = useState(false);
  const [mensaje, setMensaje] = useState({ tipo: '', texto: '' });
  const [busqueda, setBusqueda] = useState('');
  
  // Estado para el filtro desde las Tarjetas Superiores
  const [filtroEstado, setFiltroEstado] = useState('TODOS');

  // Modales
  const [modalDetalleAbierto, setModalDetalleAbierto] = useState(false);
  const [proyectoSeleccionado, setProyectoSeleccionado] = useState(null);

  const [modalNuevoPedidoAbierto, setModalNuevoPedidoAbierto] = useState(false);
  
  // Formulario con la cabecera comercial + Arreglo de PEDIDO_DETALLE
  const [nuevoPedido, setNuevoPedido] = useState({
    numero_pedido: '',
    cliente_nombre: '',
    contacto_nombre: '',
    contacto_telefono: '',
    contacto_email: '',
    ubicacion_cliente: '',
    fecha_compromiso: '',
    requisitos_cliente: '',
    detalles: [
      { id: 1, codigo_producto: '', descripcion: 'Brida Forjada 12 ANSI 600', tipo: 'pieza', cantidad_solicitada: 1, unidad: 'UND', prioridad: 'MEDIA', observaciones: '' }
    ]
  });

  useEffect(() => {
    cargarProyectos();
  }, []);

  const cargarProyectos = async () => {
    try {
      setLoading(true);
      const res = await API.get('/proyectos/');
      setProyectos(Array.isArray(res.data) ? res.data : []);
    } catch (error) {
      try {
        const fetchRes = await fetch('http://127.0.0.1:8000/api/v1/proyectos/');
        const data = await fetchRes.json();
        setProyectos(Array.isArray(data) ? data : []);
      } catch (err) {
        setMensaje({ tipo: 'error', texto: 'No se pudo conectar con el servidor Backend.' });
      }
    } finally {
      setLoading(false);
    }
  };

  // --- LÓGICA DE LA GRILLA DE PEDIDO_DETALLE ---
  const handleAgregarFilaDetalle = () => {
    setNuevoPedido(prev => ({
      ...prev,
      detalles: [
        ...prev.detalles,
        { id: Date.now(), codigo_producto: '', descripcion: '', tipo: 'pieza', cantidad_solicitada: 1, unidad: 'UND', prioridad: 'MEDIA', observaciones: '' }
      ]
    }));
  };

  const handleEliminarFilaDetalle = (id) => {
    if (nuevoPedido.detalles.length === 1) {
      alert("El pedido comercial debe tener al menos una pieza, servicio o trabajo registrado.");
      return;
    }
    setNuevoPedido(prev => ({
      ...prev,
      detalles: prev.detalles.filter(item => item.id !== id)
    }));
  };

  const handleCambioDetalle = (id, campo, valor) => {
    setNuevoPedido(prev => ({
      ...prev,
      detalles: prev.detalles.map(item => 
        item.id === id ? { ...item, [campo]: valor } : item
      )
    }));
  };

  // --- ENVÍO DE FORMULARIO ---
  const handleCrearNuevoPedido = async (e) => {
    e.preventDefault();
    setMensaje({ tipo: '', texto: '' });

    try {
      setLoading(true);
      await API.post('/proyectos/', nuevoPedido);
      setMensaje({ tipo: 'exito', texto: `✅ Pedido Comercial N° ${nuevoPedido.numero_pedido} registrado con ${nuevoPedido.detalles.length} ítem(s) en PEDIDO_DETALLE.` });
      setModalNuevoPedidoAbierto(false);
      resetFormularioNuevo();
      cargarProyectos();
    } catch (error) {
      try {
        const res = await fetch('http://127.0.0.1:8000/api/v1/proyectos/', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(nuevoPedido)
        });

        if (res.ok) {
          setMensaje({ tipo: 'exito', texto: `✅ Pedido Comercial N° ${nuevoPedido.numero_pedido} registrado exitosamente.` });
          setModalNuevoPedidoAbierto(false);
          resetFormularioNuevo();
          cargarProyectos();
        } else {
          setMensaje({ tipo: 'error', texto: 'No se pudo registrar el nuevo pedido.' });
        }
      } catch (err) {
        setMensaje({ tipo: 'error', texto: 'Error al enviar la solicitud al servidor.' });
      }
    } finally {
      setLoading(false);
    }
  };

  const handleConfirmarProyecto = async (idProyecto) => {
    try {
      setLoading(true);
      await API.patch(`/proyectos/${idProyecto}/confirmar`);
      setMensaje({ tipo: 'exito', texto: '✅ Pedido comercial confirmado correctamente.' });
      cargarProyectos();
    } catch (error) {
      setMensaje({ tipo: 'error', texto: 'Error al confirmar el pedido comercial.' });
    } finally {
      setLoading(false);
    }
  };

  const resetFormularioNuevo = () => {
    setNuevoPedido({
      numero_pedido: '',
      cliente_nombre: '',
      contacto_nombre: '',
      contacto_telefono: '',
      contacto_email: '',
      ubicacion_cliente: '',
      fecha_compromiso: '',
      requisitos_cliente: '',
      detalles: [
        { id: 1, codigo_producto: '', descripcion: 'Pieza mecanizada', tipo: 'pieza', cantidad_solicitada: 1, unidad: 'UND', prioridad: 'MEDIA', observaciones: '' }
      ]
    });
  };

  // Estados automáticos calculados por el backend (estado_pedido, total_pendiente, bloqueado)
  const ESTILO_ESTADO_PEDIDO = {
    RECIBIDO: 'bg-slate-100 text-slate-700 border-slate-300',
    EN_ESTRUCTURACION: 'bg-blue-100 text-blue-800 border-blue-300',
    PARCIALMENTE_ASIGNADO: 'bg-amber-100 text-amber-800 border-amber-300',
    ASIGNADO: 'bg-emerald-100 text-emerald-800 border-emerald-300',
    EN_PRODUCCION: 'bg-indigo-100 text-indigo-800 border-indigo-300',
    ENTREGADO: 'bg-teal-100 text-teal-800 border-teal-300',
    CERRADO: 'bg-slate-200 text-slate-700 border-slate-300',
    CANCELADO: 'bg-red-100 text-red-800 border-red-300',
  };
  const ETIQUETA_ESTADO_PEDIDO = (e) => (e || 'RECIBIDO').replaceAll('_', ' ');

  const cumpleFiltro = (p, filtro) => {
    switch (filtro) {
      case 'TODOS': return true;
      case 'CONFIRMADO': return !!p.confirmado;
      case 'PENDIENTE': return !p.confirmado;
      case 'PENDIENTES': return (p.total_pendiente || 0) > 0;
      case 'EN_ESTRUCTURACION': return p.estado_pedido === 'EN_ESTRUCTURACION';
      case 'PARCIALES': return p.estado_pedido === 'PARCIALMENTE_ASIGNADO';
      case 'ASIGNADOS': return p.estado_pedido === 'ASIGNADO';
      case 'BLOQUEADOS': return !!p.bloqueado;
      case 'CERRADOS': return ['ENTREGADO', 'CERRADO', 'CANCELADO'].includes(p.estado_pedido);
      default: return true;
    }
  };

  const totalProyectos = proyectos.length;
  const confirmados = proyectos.filter(p => p.confirmado).length;
  const pendientes = proyectos.filter(p => !p.confirmado).length;

  const proyectosFiltrados = proyectos.filter((p) => {
    const termino = busqueda.toLowerCase().trim();
    const pedido = (p.numero_pedido || '').toLowerCase();
    const cliente = (p.cliente_nombre || '').toLowerCase();
    const coincideBusqueda = pedido.includes(termino) || cliente.includes(termino);

    return coincideBusqueda && cumpleFiltro(p, filtroEstado);
  });

  return (
    <div className="p-6 bg-slate-50 min-h-screen space-y-6">
      {/* HEADER PRINCIPAL */}
      <header className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
            <span>💼</span> Ventas y Pedidos Comerciales (PM-01)
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Registro de Pedidos Comerciales, Desglose PEDIDO_DETALLE y Fechas de Compromiso [ISO 9001:2026 / SAP B1]
          </p>
        </div>
        <div className="flex items-center gap-2 self-end sm:self-auto">
          <button 
            onClick={() => setModalNuevoPedidoAbierto(true)}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg shadow-sm transition flex items-center gap-1.5"
          >
            <span>➕</span> Nuevo Pedido Comercial
          </button>
          <button 
            onClick={cargarProyectos}
            className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-lg border border-slate-300 transition flex items-center gap-1.5"
          >
            <span>🔄</span> Recargar
          </button>
        </div>
      </header>

      {/* NOTIFICACIONES */}
      {mensaje.texto && (
        <div className={`p-4 rounded-lg text-sm font-semibold border ${
          mensaje.tipo === 'exito' ? 'bg-emerald-50 text-emerald-800 border-emerald-200' : 'bg-red-50 text-red-800 border-red-200'
        }`}>
          {mensaje.texto}
        </div>
      )}

      {/* TARJETAS DE INDICADORES INTERACTIVAS */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <button
          type="button"
          onClick={() => setFiltroEstado('TODOS')}
          className={`p-4 rounded-xl border text-left transition-all shadow-sm ${
            filtroEstado === 'TODOS'
              ? 'bg-blue-50/80 border-blue-500 ring-2 ring-blue-400/30'
              : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50'
          }`}
        >
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wide">Total Pedidos Registrados</span>
          <p className="text-2xl font-bold text-slate-800 mt-1">{totalProyectos}</p>
          <span className="text-[10px] text-blue-600 font-semibold mt-1 block">🔍 Haz clic para ver todos</span>
        </button>

        <button
          type="button"
          onClick={() => setFiltroEstado('CONFIRMADO')}
          className={`p-4 rounded-xl border text-left transition-all shadow-sm ${
            filtroEstado === 'CONFIRMADO'
              ? 'bg-emerald-50/80 border-emerald-500 ring-2 ring-emerald-400/30'
              : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50'
          }`}
        >
          <span className="text-xs font-bold text-emerald-600 uppercase tracking-wide">Pedidos Confirmados</span>
          <p className="text-2xl font-bold text-emerald-700 mt-1">{confirmados}</p>
          <span className="text-[10px] text-emerald-600 font-semibold mt-1 block">🔍 Filtrar por Confirmados</span>
        </button>

        <button
          type="button"
          onClick={() => setFiltroEstado('PENDIENTE')}
          className={`p-4 rounded-xl border text-left transition-all shadow-sm ${
            filtroEstado === 'PENDIENTE'
              ? 'bg-amber-50/80 border-amber-500 ring-2 ring-amber-400/30'
              : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50'
          }`}
        >
          <span className="text-xs font-bold text-amber-600 uppercase tracking-wide">En Revisión / Pendientes</span>
          <p className="text-2xl font-bold text-amber-700 mt-1">{pendientes}</p>
          <span className="text-[10px] text-amber-600 font-semibold mt-1 block">🔍 Filtrar por Pendientes</span>
        </button>
      </div>

      {/* TABLA DE PEDIDOS COMERCIALES */}
      <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-3 border-b pb-3">
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-bold text-slate-700">Listado de Pedidos Comerciales</h2>
            {filtroEstado !== 'TODOS' && (
              <span className="px-2 py-0.5 bg-blue-100 text-blue-800 text-[10px] font-bold rounded uppercase">
                Filtro Activo: {filtroEstado}
              </span>
            )}
          </div>
          
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 w-full md:w-auto">
            <select
              value={filtroEstado}
              onChange={(e) => setFiltroEstado(e.target.value)}
              className="p-2 border border-slate-300 rounded-lg text-xs bg-slate-50 font-medium text-slate-700 focus:bg-white focus:outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="TODOS">Todos los Estados</option>
              <option value="CONFIRMADO">CONFIRMADOS (comercial)</option>
              <option value="PENDIENTE">POR CONFIRMAR (comercial)</option>
              <option value="PENDIENTES">Con cantidad pendiente de asignar</option>
              <option value="EN_ESTRUCTURACION">En estructuración</option>
              <option value="PARCIALES">Parcialmente asignados</option>
              <option value="ASIGNADOS">Asignados</option>
              <option value="BLOQUEADOS">Bloqueados</option>
              <option value="CERRADOS">Cerrados</option>
            </select>

            <input
              type="text"
              placeholder="🔍 Buscar por N° Pedido o Cliente..."
              value={busqueda}
              onChange={(e) => setBusqueda(e.target.value)}
              className="w-full sm:w-72 p-2 border border-slate-300 rounded-lg text-xs bg-slate-50 focus:bg-white focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600 border-collapse">
            <thead>
              <tr className="bg-slate-100 text-slate-700 font-bold uppercase border-b border-slate-200">
                <th className="p-3">N° Pedido</th>
                <th className="p-3">Cliente</th>
                <th className="p-3">Resumen de Piezas / Trabajos Solicitados</th>
                <th className="p-3 text-center">Solicitada / Asignada / Pendiente</th>
                <th className="p-3">Fecha Compromiso Cliente</th>
                <th className="p-3">Estado del Pedido</th>
                <th className="p-3 text-center">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {proyectosFiltrados.length === 0 ? (
                <tr>
                  <td colSpan="7" className="p-6 text-center text-slate-400 font-medium">
                    {loading ? 'Cargando pedidos comerciales...' : 'No hay pedidos comerciales que coincidan con el filtro seleccionado.'}
                  </td>
                </tr>
              ) : (
                proyectosFiltrados.map((p) => (
                  <tr key={p.id_proyecto} className="hover:bg-slate-50 transition">
                    <td className="p-3 font-bold font-mono text-purple-700 text-sm">
                      📋 {p.numero_pedido || 'PED-S/N'}
                    </td>

                    <td className="p-3 font-bold text-slate-800">
                      {p.cliente_nombre}
                      {p.contacto_nombre && <div className="text-[10px] text-slate-400 font-medium">👤 {p.contacto_nombre}</div>}
                    </td>

                    <td className="p-3 font-medium text-slate-800">{p.detalle_producto || 'Pieza Mecanizada'}</td>

                    <td className="p-3 text-center whitespace-nowrap">
                      <div className="font-bold">
                        <span className="text-blue-900">{p.total_solicitado ?? p.cantidad ?? 0}</span>
                        {' / '}<span className="text-emerald-700">{p.total_asignado ?? 0}</span>
                        {' / '}<span className="text-amber-700">{p.total_pendiente ?? 0}</span>
                      </div>
                      <div className="w-24 h-1.5 bg-slate-200 rounded mx-auto mt-1 overflow-hidden">
                        <div className="h-full bg-emerald-500" style={{ width: `${p.cobertura_pct || 0}%` }} />
                      </div>
                      <div className="text-[10px] text-slate-500 mt-0.5">{p.cobertura_pct || 0}% cubierto por OTs</div>
                    </td>

                    <td className="p-3 font-bold text-slate-800 whitespace-nowrap bg-amber-50/40 px-2 rounded border border-amber-200/50">
                      📅 {p.fecha_compromiso || 'Sin fecha de entrega'}
                    </td>

                    <td className="p-3 whitespace-nowrap">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${ESTILO_ESTADO_PEDIDO[p.estado_pedido] || ESTILO_ESTADO_PEDIDO.RECIBIDO}`}>
                        {ETIQUETA_ESTADO_PEDIDO(p.estado_pedido)}
                      </span>
                      {p.bloqueado && (
                        <span className="ml-1 px-2 py-0.5 rounded text-[10px] font-bold bg-red-100 text-red-800 border border-red-300">⛔ BLOQUEADO</span>
                      )}
                      {!p.confirmado && (
                        <div className="text-[10px] text-amber-700 font-semibold mt-0.5">Sin confirmar</div>
                      )}
                    </td>

                    <td className="p-3 text-center whitespace-nowrap space-x-2">
                      <button
                        type="button"
                        onClick={() => {
                          setProyectoSeleccionado(p);
                          setModalDetalleAbierto(true);
                        }}
                        className="px-2.5 py-1 font-semibold rounded text-[11px] bg-slate-700 text-white hover:bg-slate-800 transition shadow-sm"
                      >
                        👁️ Ver Expediente
                      </button>

                      {!p.confirmado && (
                        <button
                          type="button"
                          onClick={() => handleConfirmarProyecto(p.id_proyecto)}
                          className="px-2.5 py-1 font-semibold rounded text-[11px] bg-emerald-600 text-white hover:bg-emerald-700 transition shadow-sm"
                        >
                          ✓ Confirmar
                        </button>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL 1: RADICACIÓN CON GRILLA PEDIDO_DETALLE */}
      {modalNuevoPedidoAbierto && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex justify-center items-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-5xl w-full p-6 space-y-4 max-h-[92vh] overflow-y-auto">
            <div className="flex justify-between items-start border-b pb-3">
              <div>
                <span className="px-2 py-0.5 bg-blue-100 text-blue-800 text-[10px] font-bold rounded uppercase">
                  Radicación de Pedido Comercial [PM-01 / ISO 9001:2026]
                </span>
                <h3 className="text-xl font-bold text-slate-800 mt-1">
                  Registrar Nuevo Pedido Comercial
                </h3>
              </div>
              <button onClick={() => setModalNuevoPedidoAbierto(false)} className="text-slate-400 hover:text-slate-600 font-bold text-lg">✕</button>
            </div>

            <form onSubmit={handleCrearNuevoPedido} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">N° Pedido Comercial *</label>
                <input
                  type="text"
                  required
                  placeholder="Ej. PED-2026-105"
                  value={nuevoPedido.numero_pedido}
                  onChange={(e) => setNuevoPedido({ ...nuevoPedido, numero_pedido: e.target.value })}
                  className="w-full p-2 border border-slate-300 rounded font-mono font-bold text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Nombre Razón Social Cliente *</label>
                  <input
                    type="text"
                    required
                    placeholder="Ej. Ecopetrol S.A."
                    value={nuevoPedido.cliente_nombre}
                    onChange={(e) => setNuevoPedido({ ...nuevoPedido, cliente_nombre: e.target.value })}
                    className="w-full p-2 border border-slate-300 rounded font-bold text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Ubicación / Planta de Entrega</label>
                  <input
                    type="text"
                    placeholder="Ej. Refinería Barrancabermeja"
                    value={nuevoPedido.ubicacion_cliente}
                    onChange={(e) => setNuevoPedido({ ...nuevoPedido, ubicacion_cliente: e.target.value })}
                    className="w-full p-2 border border-slate-300 rounded text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Contacto Cliente</label>
                  <input
                    type="text"
                    placeholder="Ing. Juan Pérez"
                    value={nuevoPedido.contacto_nombre}
                    onChange={(e) => setNuevoPedido({ ...nuevoPedido, contacto_nombre: e.target.value })}
                    className="w-full p-2 border border-slate-300 rounded text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Teléfono Contacto</label>
                  <input
                    type="text"
                    placeholder="+57 300 000 0000"
                    value={nuevoPedido.contacto_telefono}
                    onChange={(e) => setNuevoPedido({ ...nuevoPedido, contacto_telefono: e.target.value })}
                    className="w-full p-2 border border-slate-300 rounded text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Correo Electrónico</label>
                  <input
                    type="email"
                    placeholder="compras@cliente.com"
                    value={nuevoPedido.contacto_email}
                    onChange={(e) => setNuevoPedido({ ...nuevoPedido, contacto_email: e.target.value })}
                    className="w-full p-2 border border-slate-300 rounded text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>
              </div>

              {/* GRILLA ENTIDAD INTERMEDIA: PEDIDO_DETALLE */}
              <div className="border border-slate-200 rounded-xl p-3 bg-slate-50/50 space-y-3">
                <div className="flex justify-between items-center border-b pb-2">
                  <h4 className="font-bold text-slate-800 flex items-center gap-1.5 text-xs">
                    <span>📦</span> Estructuración de PEDIDO_DETALLE (Piezas, Servicios o Trabajos)
                  </h4>
                  <button
                    type="button"
                    onClick={handleAgregarFilaDetalle}
                    className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded text-[11px] flex items-center gap-1 shadow-sm transition"
                  >
                    ➕ Agregar Ítem a PEDIDO_DETALLE
                  </button>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs bg-white border border-slate-200 rounded-lg overflow-hidden">
                    <thead className="bg-slate-100 text-slate-700 font-bold border-b">
                      <tr>
                        <th className="p-2.5 w-10 text-center">#</th>
                        <th className="p-2.5 w-28">Código Prod.</th>
                        <th className="p-2.5">Descripción del Elemento / Pieza / Servicio *</th>
                        <th className="p-2.5 w-28">Tipo *</th>
                        <th className="p-2.5 w-24 text-center">Cantidad *</th>
                        <th className="p-2.5 w-20">Unidad</th>
                        <th className="p-2.5 w-24">Prioridad</th>
                        <th className="p-2.5 w-10 text-center"></th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {nuevoPedido.detalles.map((det, index) => (
                        <tr key={det.id} className="hover:bg-slate-50">
                          <td className="p-2 text-center font-bold text-slate-400">{index + 1}</td>
                          <td className="p-2">
                            <input
                              type="text"
                              placeholder="PROD-01"
                              value={det.codigo_producto}
                              onChange={(e) => handleCambioDetalle(det.id, 'codigo_producto', e.target.value)}
                              className="w-full p-1.5 border border-slate-300 rounded font-mono font-bold text-blue-700 focus:outline-none"
                            />
                          </td>
                          <td className="p-2">
                            <input
                              type="text"
                              required
                              placeholder="Brida Forjada 12 ANSI / Serv. Metrología"
                              value={det.descripcion}
                              onChange={(e) => handleCambioDetalle(det.id, 'descripcion', e.target.value)}
                              className="w-full p-1.5 border border-slate-300 rounded font-medium text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500"
                            />
                          </td>
                          <td className="p-2">
                            <select
                              value={det.tipo}
                              onChange={(e) => handleCambioDetalle(det.id, 'tipo', e.target.value)}
                              className="w-full p-1.5 border border-slate-300 rounded bg-white font-medium"
                            >
                              <option value="pieza">Pieza</option>
                              <option value="conjunto">Conjunto</option>
                              <option value="servicio">Servicio</option>
                              <option value="trabajo">Trabajo</option>
                              <option value="producto">Producto</option>
                            </select>
                          </td>
                          <td className="p-2">
                            <input
                              type="number"
                              min="1"
                              required
                              value={det.cantidad_solicitada}
                              onChange={(e) => handleCambioDetalle(det.id, 'cantidad_solicitada', parseInt(e.target.value) || 1)}
                              className="w-full p-1.5 border border-slate-300 rounded font-bold text-center text-slate-800 focus:outline-none"
                            />
                          </td>
                          <td className="p-2">
                            <input
                              type="text"
                              value={det.unidad}
                              onChange={(e) => handleCambioDetalle(det.id, 'unidad', e.target.value)}
                              className="w-full p-1.5 border border-slate-300 rounded text-center text-slate-700"
                            />
                          </td>
                          <td className="p-2">
                            <select
                              value={det.prioridad}
                              onChange={(e) => handleCambioDetalle(det.id, 'prioridad', e.target.value)}
                              className="w-full p-1.5 border border-slate-300 rounded bg-white font-bold text-slate-700"
                            >
                              <option value="ALTA">ALTA</option>
                              <option value="MEDIA">MEDIA</option>
                              <option value="BAJA">BAJA</option>
                            </select>
                          </td>
                          <td className="p-2 text-center">
                            <button
                              type="button"
                              onClick={() => handleEliminarFilaDetalle(det.id)}
                              className="text-red-500 hover:text-red-700 font-bold px-1.5 py-0.5 rounded hover:bg-red-50 transition"
                            >
                              🗑️
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-800 mb-1 flex items-center gap-1">
                  <span>📅</span> Fecha de Compromiso con el Cliente (Entrega) *
                </label>
                <input
                  type="date"
                  required
                  value={nuevoPedido.fecha_compromiso}
                  onChange={(e) => setNuevoPedido({ ...nuevoPedido, fecha_compromiso: e.target.value })}
                  className="w-full p-2 border border-blue-300 rounded font-bold text-blue-900 bg-blue-50/50 focus:bg-white focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Requisitos Técnicos y de Calidad Generales *</label>
                <textarea
                  rows="2"
                  required
                  placeholder="Norma ASME, Certificado de Calidad 3.1..."
                  value={nuevoPedido.requisitos_cliente}
                  onChange={(e) => setNuevoPedido({ ...nuevoPedido, requisitos_cliente: e.target.value })}
                  className="w-full p-2 border border-slate-300 rounded text-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500"
                ></textarea>
              </div>

              <div className="flex justify-end gap-2 border-t pt-3">
                <button
                  type="button"
                  onClick={() => setModalNuevoPedidoAbierto(false)}
                  className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold rounded transition"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded transition shadow-sm"
                >
                  {loading ? 'Guardando...' : '💾 Radicar Pedido Comercial'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: EXPEDIENTE COMERCIAL CON DETALLE COMPLETO DE PEDIDO_DETALLE */}
      {modalDetalleAbierto && proyectoSeleccionado && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex justify-center items-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl max-w-3xl w-full p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-start border-b pb-3">
              <div>
                <span className="px-2 py-0.5 bg-blue-100 text-blue-800 text-[10px] font-bold rounded uppercase">
                  Expediente Comercial [ISO 9001:2026 / SAP B1]
                </span>
                <h3 className="text-xl font-bold text-slate-800 mt-1">
                  Pedido Comercial N°: <span className="text-purple-700 font-mono">{proyectoSeleccionado.numero_pedido}</span>
                </h3>
              </div>
              <button onClick={() => setModalDetalleAbierto(false)} className="text-slate-400 hover:text-slate-600 font-bold text-lg">✕</button>
            </div>

            <div className="text-xs bg-slate-50 p-4 rounded-lg border border-slate-200 grid grid-cols-2 gap-3">
              <p><strong>Cliente:</strong> {proyectoSeleccionado.cliente_nombre}</p>
              <p><strong>Contacto:</strong> 👤 {proyectoSeleccionado.contacto_nombre || 'N/A'}</p>
              <p><strong>Ubicación Planta:</strong> {proyectoSeleccionado.ubicacion_cliente || 'Planta Principal'}</p>
              <p><strong>Fecha Compromiso Entrega:</strong> <span className="font-bold text-slate-800">📅 {proyectoSeleccionado.fecha_compromiso || 'Sin fecha'}</span></p>
              <p className="col-span-2">
                <strong>Estado:</strong>{' '}
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${ESTILO_ESTADO_PEDIDO[proyectoSeleccionado.estado_pedido] || ESTILO_ESTADO_PEDIDO.RECIBIDO}`}>
                  {ETIQUETA_ESTADO_PEDIDO(proyectoSeleccionado.estado_pedido)}
                </span>
                {' · '}<strong>Solicitado:</strong> <span className="font-bold text-blue-900">{proyectoSeleccionado.total_solicitado ?? proyectoSeleccionado.cantidad ?? 0}</span>
                {' · '}<strong>Asignado:</strong> <span className="font-bold text-emerald-700">{proyectoSeleccionado.total_asignado ?? 0}</span>
                {' · '}<strong>Pendiente:</strong> <span className="font-bold text-amber-700">{proyectoSeleccionado.total_pendiente ?? 0}</span>
              </p>
            </div>

            {/* MATRIZ DE DESGLOSE PEDIDO_DETALLE */}
            <div className="space-y-2">
              <h4 className="font-bold text-slate-700 text-xs">📦 Detalle de Elementos / Piezas en PEDIDO_DETALLE</h4>
              <div className="border border-slate-200 rounded-lg overflow-hidden text-xs">
                <table className="w-full text-left border-collapse">
                  <thead className="bg-slate-100 font-bold text-slate-700 border-b">
                    <tr>
                      <th className="p-2 w-10 text-center">#</th>
                      <th className="p-2">Descripción del Elemento / Pieza</th>
                      <th className="p-2 w-20 uppercase">Tipo</th>
                      <th className="p-2 w-20 text-center">Solicitada</th>
                      <th className="p-2 w-20 text-center">Asignada</th>
                      <th className="p-2 w-20 text-center">Pendiente</th>
                      <th className="p-2 w-20">Prioridad</th>
                      <th className="p-2">OTs que ejecutan la línea</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 text-slate-600">
                    {proyectoSeleccionado.detalles && proyectoSeleccionado.detalles.length > 0 ? (
                      proyectoSeleccionado.detalles.map((det, idx) => (
                        <tr key={idx} className="hover:bg-slate-50">
                          <td className="p-2 text-center font-bold text-slate-400">{idx + 1}</td>
                          <td className="p-2 font-bold text-slate-800">{det.descripcion}</td>
                          <td className="p-2 uppercase font-semibold text-purple-700">{det.tipo || 'pieza'}</td>
                          <td className="p-2 text-center font-bold text-blue-900">{det.cantidad_solicitada} {det.unidad}</td>
                          <td className="p-2 text-center font-bold text-emerald-700">{det.cantidad_asignada} {det.unidad}</td>
                          <td className="p-2 text-center font-bold text-amber-700">{det.cantidad_pendiente} {det.unidad}</td>
                          <td className="p-2 font-bold text-slate-700">{det.prioridad || 'MEDIA'}</td>
                          <td className="p-2">
                            {(det.ot_detalles || []).length === 0 ? (
                              <span className="text-slate-400">Sin OT</span>
                            ) : (
                              <div className="flex flex-wrap gap-1">
                                {det.ot_detalles.map((ot) => (
                                  <span
                                    key={ot.ot_detalle_id}
                                    className={`px-1.5 py-0.5 rounded border font-mono text-[10px] font-bold ${
                                      ot.estado_ot === 'ANULADA'
                                        ? 'bg-slate-100 text-slate-400 border-slate-200 line-through'
                                        : 'bg-purple-50 text-purple-800 border-purple-200'
                                    }`}
                                    title={ot.estado_ot || ''}
                                  >
                                    OT-{ot.codigo_op || '—'} · {ot.cantidad_asignada}
                                  </span>
                                ))}
                              </div>
                            )}
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan="8" className="p-3 text-center text-slate-400">
                          {proyectoSeleccionado.detalle_producto || 'Sin detalle especificado.'}
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="space-y-1">
              <h4 className="font-bold text-slate-700 text-xs">Requisitos Técnicos Generales del Cliente</h4>
              <div className="p-3 bg-slate-100 rounded text-xs text-slate-700 font-medium">
                {proyectoSeleccionado.requisitos_cliente || 'Sin requisitos especificados.'}
              </div>
            </div>

            <div className="flex justify-end border-t pt-3">
              <button onClick={() => setModalDetalleAbierto(false)} className="px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded text-xs transition">
                Cerrar Expediente
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}